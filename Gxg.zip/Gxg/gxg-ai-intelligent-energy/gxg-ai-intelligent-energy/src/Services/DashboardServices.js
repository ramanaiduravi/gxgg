import { api_url } from '../Utils/Constants';

export const getEnergyScannerData = (month = false) => {
    return new Promise(async (resolve, reject) => {
        await fetch(`${api_url}/energyscanner${month ? `?month=${month}` : ''}`, {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                "Access-Control-Request-Headers": "*"
            }
        })
            .then(response => {
                return response.json()
            })
            .then(response => {
                if (response.statusCode === 200) {
                    resolve(response);
                } else {
                    reject(response);
                }
            })
            .catch(err => reject(err));
    })
}