import { api_url, docuSign_url } from '../Utils/Constants';

export const signIn = (reqData) => {
    return new Promise(async (resolve, reject) => {
        await fetch(`${api_url}/login`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                "Access-Control-Request-Headers": "*"
            },
            body: JSON.stringify(reqData)
        })
            .then(response => {
                return response.json()
            })
            .then(response => {
                if (response.statusCode === 200) {
                    resolve(response);
                } else {
                    reject(response);
                }
            })
            .catch(err => reject(err));
    })
}

export const signUp = (reqData) => {
    return new Promise(async (resolve, reject) => {
        await fetch(`${api_url}/signup`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                "Access-Control-Request-Headers": "*"
            },
            body: JSON.stringify(reqData)
        })
            .then(response => {
                return response.json()
            })
            .then(response => {
                if (response.statusCode === 200) {
                    resolve(response);
                } else {
                    reject(response);
                }
            })
            .catch(err => reject(err));
    })
}

// Docusign Related Services//


export const getStatus = () => {
    return new Promise(async (resolve, reject) => {
        await fetch(`${docuSign_url}/get_status`, {
            method: 'GET',
        })
            .then(response => {
                return response.json()
            })
            .then(response => {
                resolve(response);
            })
            .catch(err => reject(err));
    })
}

export const jwtAuth = () => {
    return new Promise(async (resolve, reject) => {
        await fetch(`${docuSign_url}/jwt_auth`, {
            method: 'POST',
        })
            .then(response => {
                return response.json()
            })
            .then(response => {
                resolve(response);
            })
            .catch(err => reject(err));
    })
}

export const docuSign = (subscriber_id) => {
    return new Promise(async (resolve, reject) => {
        await fetch(`${docuSign_url}/docusign?subscriber_id=${subscriber_id}`, {
            method: 'GET',
        })
            .then(response => {
                return response.json()
            })
            .then(response => {
                resolve(response);
            })
            .catch(err => reject(err));
    })
}

export const docuSignSuccess = (reqData) => {
    return new Promise(async (resolve, reject) => {
        await fetch(`${docuSign_url}/docusign_success`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                // "Access-Control-Request-Headers": "*"
            },
            body: JSON.stringify(reqData)
        })
            .then(response => {
                return response.json()
            })
            .then(response => {
                console.log('kskresp', response);
                resolve(response);
            })
            .catch(err => reject(err));
    })
}


// Docusign Related Services//

//PG related Services

export const getCheckoutId = (reqData) => {
    return new Promise(async (resolve, reject) => {
        await fetch(`${api_url}/stripe/checkout`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                "Access-Control-Request-Headers": "*"
            },
            body: JSON.stringify(reqData)
        })
            .then(response => {
                return response.json()
            })
            .then(response => {
                resolve(response);
            })
            .catch(err => reject(err));
    })
}

export const paymentSuccess = (subscriber_id) => {
    return new Promise(async (resolve, reject) => {
        await fetch(`${api_url}/stripe/payment_success?subscriber_id=${subscriber_id}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                "Access-Control-Request-Headers": "*"
            }
        })
            .then(response => {
                return response.json()
            })
            .then(response => {
                resolve(response);
            })
            .catch(err => reject(err));
    })
}

export const paymentFailure = (subscriber_id) => {
    return new Promise(async (resolve, reject) => {
        await fetch(`${api_url}/stripe/payment_failure?subscriber_id=${subscriber_id}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                "Access-Control-Request-Headers": "*"
            }
        })
            .then(response => {
                return response.json()
            })
            .then(response => {
                resolve(response);
            })
            .catch(err => reject(err));
    })
}

//PG related Services
