import React from 'react';
import { BrowserRouter, Route, Switch } from 'react-router-dom';
import Login from './Pages/Login';
import { createBrowserHistory } from 'history';
import Register from './Pages/Register';
import Profile from './Pages/Profile';
import Dashboard from './Pages/Dashboard';
import AIImpact from './Pages/AIImpact';
import Page404 from './Pages/Page404';
import PrivateRoute from './Utils/PrivateRoute';
import { Provider } from 'react-redux';
import store from './store';
import Docusign from './Pages/Register/Docusign';
import CompleteDocusign from './Pages/Register/CompleteDocusign';
import Payment from './Pages/Register/Payment';
import PaymentStatus from './Pages/Register/PaymentStatus';



const App = () => {
  const history = createBrowserHistory();
  return (
    <Provider store={store}>
      <BrowserRouter history={history}>
        <Switch>
          <Route exact path="/" exact component={Login} />
          <Route exact path="/login" component={Login} />
          <Route exact path="/register" component={Register} />
          <Route exact path="/register/docusign" component={Docusign} />
          <Route exact path="/docusign/complete" component={CompleteDocusign} />
          <Route exact path="/register/payment" component={Payment} />
          <Route exact path="/register/paymentstatus" component={PaymentStatus} />
          <PrivateRoute exact path="/dashboard" component={Dashboard} />
          <PrivateRoute exact path="/ai-impact" component={AIImpact} />
          <PrivateRoute exact path="/profile" component={Profile} />
          <Route component={Page404} />
        </Switch>
      </BrowserRouter>
    </Provider>
  );
}

export default App;
