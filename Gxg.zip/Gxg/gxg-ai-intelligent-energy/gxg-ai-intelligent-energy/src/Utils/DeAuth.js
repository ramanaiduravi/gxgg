import React from 'react';
import {Redirect} from 'react-router-dom';

const DeAuth = () => {
    localStorage.removeItem('userData');
    return (
        <div>

        </div>
    );
};

export default DeAuth;