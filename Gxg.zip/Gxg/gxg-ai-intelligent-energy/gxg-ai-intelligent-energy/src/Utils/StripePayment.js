import React from 'react';
import { loadStripe } from '@stripe/stripe-js';

const stripePromise = loadStripe('pk_test_51Hlcw7CsZRpcinFZSGQ3g1ninCNSqESiWmYEY0KMkO4cWVHZJpXSn5PueU0GfUBM3NhOyksOfZEUDdt5RY9dBKT400fBdyoyOJ');

const StripePayment = {
    proceedToPayment: async (subId) => {
        // Get Stripe.js instance
        const stripe = await stripePromise;

        // Call your backend to create the Checkout Session
        // const response = await fetch('http://127.0.0.1:5000/create-checkout-session', { method: 'POST' });

        // const session = await response.json();

        // When the customer clicks on the button, redirect them to Checkout.
        const result = await stripe.redirectToCheckout({
            sessionId: subId,
            // sessionId: session.id,
        });

        if (result.error) {
            // If `redirectToCheckout` fails due to a browser or network
            // error, display the localized error message to your customer
            // using `result.error.message`.
        }
    },
}

export default StripePayment;