export const api_url = 'https://cn8336y9re.execute-api.us-west-1.amazonaws.com/prod';
export const docuSign_url = 'http://ec2-54-151-76-120.us-west-1.compute.amazonaws.com';