import React from 'react';
import Preloader from '../../Components/Preloader';
import { Link, Redirect } from 'react-router-dom';
import { Formik, Form, ErrorMessage } from "formik";
import { connect } from 'react-redux';
import { ActionCreators } from '../../Actions';
import { bindActionCreators } from 'redux';
import * as ActionTypes from '../../Actions/ActionTypes';


class Login extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            redirect: false,
            errorMessage: null,
            type: null, submitted: false, userData: {}, loader: false
        };
    }

    componentDidMount() {
        try {
            if (localStorage.getItem('userData')) {
                this.handleRedirect();
            }
        } catch (e) {
            if (e.code == 22) {
                // Storage full, maybe notify user or do some clean-up
            }
        }
    }

    handleRedirect = () => {
        this.setState({ redirect: true });
    }


    static getDerivedStateFromProps(props, state) {
        if (props.type === 'POST_LOGIN_SUCCESS' && state.type !== props.type) {
            localStorage.setItem('userData', JSON.stringify(props.userData));
            return {
                redirect: true, submitted: false, type: props.type, userData: props.userData, loader: props.isRequesting
            }
        } else if (props.type === 'POST_LOGIN_FAILURE' && state.type !== props.type) {
            return {
                type: props.type, errorMessage: props.message, submitted: false, redirect: false, loader: props.isRequesting
            }
        } else if (props.type === 'POST_LOGIN_PENDING') {
            return {
                submitted: true, type: props.type, redirect: false, loader: props.isRequesting
            }
        }
        return null;
    }

    renderRedirect = () => {
        if (this.state.redirect) {
            return <Redirect to='/profile' />
        }
    }
    render() {
        const emailTest = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/i;
        let { loader } = this.state;
        return (
            <div>
                {this.renderRedirect()}
                <div>
                    {/* <Preloader /> */}
                    {/*loader end*/}
                    {/*body content wrap start*/}
                    <div className="main">
                        {/*hero section start*/}
                        <section className="hero-section ptb-100 gradient-overlay full-screen" style={{ background: 'url("assets/images/hero-bg-4.jpg")no-repeat center center / cover' }}>
                            <div className="container">
                                <div className="row align-items-center justify-content-between pt-5 pt-sm-5 pt-md-5 pt-lg-0">
                                    <div className="col-md-7 col-lg-6">
                                        <div className="hero-content-left text-white">
                                            <a className="navbar-brand" href="#">
                                                <img src="assets/images/logo-white.png" width={160} alt="logo" className="img-fluid" />
                                            </a>
                                            <h1 className="text-white">Welcome Back !</h1>
                                            <p className="lead">Keep your face always toward the sunshine <br /> and shadows will fall behind you.</p>
                                        </div>
                                    </div>
                                    <div className="col-md-5 col-lg-5">
                                        <div className="card login-signup-card shadow-lg mb-0">
                                            <div className="card-body px-md-5 py-5">
                                                <div className="mb-5">

                                                    <h5 className="h3">Login</h5>
                                                    <p className="text-muted mb-0">Sign in to your account to continue.</p>
                                                </div>
                                                {/*login form*/}
                                                <Formik
                                                    initialValues={{ email: "", password: "" }}
                                                    validate={values => {
                                                        let errors = {};
                                                        if (values.email === "") {
                                                            errors.email = "Email is required";
                                                        } else if (!emailTest.test(values.email)) {
                                                            errors.email = "Invalid email address format";
                                                        }
                                                        if (values.password === "") {
                                                            errors.password = "Password is required";
                                                        }
                                                        // else if (values.password.length < 3) {
                                                        //     errors.password = "Password must be 3 characters at minimum";
                                                        // }
                                                        return errors;
                                                    }}
                                                    onSubmit={(values) => {
                                                        this.setState({ errorMessage: '' });
                                                        this.props.signIn({ user_login: values.email, passwd: values.password });
                                                    }}
                                                >
                                                    {({ values,
                                                        errors,
                                                        touched,
                                                        handleChange,
                                                        handleBlur,
                                                        handleSubmit,
                                                    }) => (
                                                            <Form className="login-signup-form">
                                                                {this.state.errorMessage && <div className="alert alert-warning">
                                                                    <p>{this.state.errorMessage}</p>
                                                                </div>}
                                                                <div className="form-group">
                                                                    <label className="pb-1">Email Address</label>
                                                                    <input name="email" type="email" className="form-control" placeholder="Enter Email" onChange={handleChange}
                                                                        /* Set onBlur to handleBlur */
                                                                        onBlur={handleBlur}
                                                                        /* Store the value of this input in values.name, make sure this is named the same as the name property on the form element */
                                                                        value={values.email} />
                                                                    <center>
                                                                        <ErrorMessage
                                                                            component="div"
                                                                            name="email"
                                                                            className="invalid-error"
                                                                        />
                                                                    </center>
                                                                </div>
                                                                {/* Password */}
                                                                <div className="form-group">
                                                                    <div className="row">
                                                                        <div className="col">
                                                                            <label className="pb-1">Password</label>
                                                                        </div>
                                                                        <div className="col-auto">
                                                                            <a href="forgot.html" className="form-text small text-muted">Forgot password?</a>
                                                                        </div>
                                                                    </div>
                                                                    <input type="password" name="password" className="form-control" placeholder="Enter Your password" onChange={handleChange}
                                                                        /* Set onBlur to handleBlur */
                                                                        onBlur={handleBlur}
                                                                        /* Store the value of this input in values.name, make sure this is named the same as the name property on the form element */
                                                                        value={values.password} />
                                                                    <center>
                                                                        <ErrorMessage
                                                                            component="div"
                                                                            name="password"
                                                                            className="invalid-error"
                                                                        />
                                                                    </center>
                                                                </div>
                                                                {/* Submit */}
                                                                <button type="submit" className="btn btn-block solid-btn border-radius mt-4 mb-3">{loader ? <i className="fas fa-spinner fa-spin fa-lg"></i> : 'Log in'}</button>
                                                            </Form>

                                                        )}
                                                </Formik>
                                            </div>
                                            <div className="card-footer bg-transparent border-top px-md-5"><small>New to GXG Family?</small>
                                                <Link to="/register" className="small"> Register</Link>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className="shape-bottom">
                                <img src="assets/images/hero-shape-bottom.svg" alt="shape" className="bottom-shape img-fluid" />
                            </div>
                        </section>
                        {/*hero section end*/}
                    </div>
                    {/*body content wrap end*/}
                </div>

            </div>
        );
    }
};

function mapStateToProps(state) {
    return {
        isRequesting: state.AuthReducer.isRequesting,
        type: state.AuthReducer.type,
        userData: state.AuthReducer.userData,
        message: state.AuthReducer.message
    }
}
function mapDispatchToProps(dispatch) {
    return bindActionCreators(ActionCreators, dispatch);
}

export default connect(mapStateToProps, mapDispatchToProps)(Login);