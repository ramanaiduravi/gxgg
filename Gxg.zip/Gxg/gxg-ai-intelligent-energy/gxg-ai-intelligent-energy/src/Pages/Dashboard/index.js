import React from 'react';
import Preloader from '../../Components/Preloader';
import { Link } from 'react-router-dom';
import TopHeader from '../../Components/TopHeader';
import SideVerticalNav from '../../Components/SideVerticalNav';
import { connect } from 'react-redux';
import { ActionCreators } from '../../Actions';
import { bindActionCreators } from 'redux';
import * as ActionTypes from '../../Actions/ActionTypes';
import _ from 'lodash';
import Chart from "react-google-charts";
import ReactEcharts from 'echarts-for-react';
import './styles.css';

class Dashboard extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            type: undefined, dashboardData: {}, errorMessage: '', loader: false, month: '', redirect: false
        }
    }

    componentDidMount() {
        // this.props.getEnergyScannerData();
        // alert(window.innerWidth);
        this.handleFetchData();
    }

    static getDerivedStateFromProps(nextProps, state) {
        if (state.type !== nextProps.type) {
            if (nextProps.type === ActionTypes.GET_ENERGYSCANNERDATA_PENDING) {
                return {
                    loader: nextProps.isRequesting,
                    type: nextProps.type
                }
            } else if (nextProps.type === ActionTypes.GET_ENERGYSCANNERDATA_SUCCESS) {
                return {
                    loader: nextProps.isRequesting,
                    type: nextProps.type,
                    dashboardData: nextProps.dashboardData,
                }
            } else if (nextProps.type === ActionTypes.GET_ENERGYSCANNERDATA_FAILURE) {
                return {
                    loader: nextProps.isRequesting,
                    type: nextProps.type,
                    errorMessage: nextProps.errorMessage,
                    dashboardData: {}
                }
            }
        } else if (nextProps.authType === ActionTypes.SIGNOUT_SUCCESS) {
            return {
                redirect: true
            }
        }
        return null;
    }

    //to handle Overall Data for ComboChart
    overAllUsage = () => {
        const { dashboardData } = this.state;
        const mappedData = _.get(dashboardData, 'energy_consumption', []).map((oData) => {
            return [_.get(oData, 'date'), _.get(oData, 'Electric'), _.get(oData, 'Solar'), _.get(oData, 'Total')];
        })
        return [['date', 'Electric', 'Solar', 'Total'], ...mappedData];
    }

    //to handle Solar Electric usage data for Pie Chart
    solarElectricUsageData = () => {
        const { dashboardData } = this.state;
        const solarElectricData = _.get(dashboardData, 'solar_electric_usage', {});
        return [['Type', 'Quantity'], [`Solar(${_.get(solarElectricData, 'month_name')})`, _.get(solarElectricData, 'Solar Usage')], [`ELectric(${_.get(solarElectricData, 'month_name')})`, _.get(solarElectricData, 'Electric Usage')]];
    }
    // to handle net SOlar Energy produced vs Consumed
    netSolarEnergyProdCons = () => {
        const { dashboardData } = this.state;
        const mappedData = _.get(dashboardData, 'net_solar_energy_produced_consumed', []).map((oData) => {
            return [_.get(oData, 'date'), _.get(oData, 'Solar Deposited'), _.get(oData, 'Solar Withdrawn')];
        })
        return [['date', 'Solar Deposited', 'Solar Withdrawn'], ...mappedData];
    }
    // to handle billdetails & Insights
    bill_details = () => {
        const { dashboardData } = this.state;
        const mappedData = _.get(dashboardData, 'bill_details', []).map((oData) => {
            return [_.get(oData, 'date'), _.get(oData, 'Electric'), _.get(oData, 'Solar'), _.get(oData, 'Total')];
        })
        return [['date', 'Electric', 'Solar', 'Total'], ...mappedData];
    }

    solarTotalBenifits = () => {

        const { dashboardData } = this.state;
        const mappedData = _.get(dashboardData, 'solar_total_benifits', []).map((oData) => {
            return [_.get(oData, 'date'), _.get(oData, 'Solar Total Benefits')];
        })
        return [['date', 'Solar Total Benefits'], ...mappedData];
    }

    getOption = () => {
        const { dashboardData } = this.state;
        return {
            title: {
                text: 'Overall Usage Insights'
            },
            tooltip: {
                trigger: 'axis',
                axisPointer: {
                    type: 'cross',
                    label: {
                        backgroundColor: '#6a7985'
                    }
                }
            },
            legend: {
                data: ['Electric', 'Green', 'Total']
            },
            toolbox: {
                feature: {
                    saveAsImage: {}
                }
            },
            grid: {
                left: '3%',
                right: '4%',
                bottom: '3%',
                containLabel: true,
            },
            xAxis: [
                {
                    name: 'Date',
                    type: 'category',
                    boundaryGap: false,
                    data: _.get(dashboardData, 'energy_consumption', []).map((oData) => {
                        return _.get(oData, 'date');
                    })
                }
            ],
            yAxis: [
                {
                    name: 'Power Consumption [KW]',
                    type: 'value'
                }
            ],
            series: [
                {
                    name: 'Electric',
                    type: 'line',
                    stack: '总量',
                    areaStyle: {},
                    data: _.get(dashboardData, 'energy_consumption', []).map((oData) => {
                        return _.get(oData, 'Electric');
                    })
                },
                {
                    name: 'Green',
                    type: 'line',
                    stack: '总量',
                    areaStyle: {},
                    data: _.get(dashboardData, 'energy_consumption', []).map((oData) => {
                        return _.get(oData, 'Green');
                    })
                },
                {
                    name: 'Total',
                    type: 'line',
                    stack: '总量',
                    areaStyle: {},
                    data: _.get(dashboardData, 'energy_consumption', []).map((oData) => {
                        return _.get(oData, 'Total');
                    })
                }
            ]
        };

    }

    getSolarElectricUsage = () => {
        const { dashboardData } = this.state;
        const solarElectricData = _.get(dashboardData, 'solar_electric_usage', {});
        return {
            // title: {
            //     text: 'Solar Electric Usage'
            // },
            tooltip: {
                trigger: 'item',
                formatter: '{a} <br/>{b} : {c} KWh ({d}%)'
            },
            legend: {
                orient: 'horizontal',
                left: 'right',
                data: ['Electric', 'Solar']
            },
            series: [
                {
                    name: `${_.get(solarElectricData, 'month_name')}`,
                    type: 'pie',
                    radius: '55%',
                    center: ['50%', '50%'],
                    label: {
                        formatter: '{b} \n ({d}%)',
                        width:'30%',
                        align:'center'
                    },
                    left:'10%',right:'10%',
                    data: [
                        {
                            value: _.get(solarElectricData, 'Electric Usage'), name: 'Electric', itemStyle: {
                                color: '#2e3192'
                            }
                        },
                        {
                            value: _.get(solarElectricData, 'Solar Usage'), name: 'Solar', itemStyle: {
                                color: '#5f5f5f'
                            }
                        },
                    ],
                    emphasis: {
                        itemStyle: {
                            shadowBlur: 10,
                            shadowOffsetX: 0,
                            shadowColor: 'rgba(0, 0, 0, 0.5)'
                        }
                    }
                }
            ]
        };
    }

    getEnergyCost = () => {
        return {
            legend: { data: ['Electric', 'Solar'] },
            tooltip: {
                trigger: 'axis',
                showContent: true
            },
            dataset: {
                source: [
                    ['product', '01', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20', '21', '22', '23', '24', '25', '26'],
                    ['Electric', 0.19, 0.21, 0.26, 0.38, 0.19, 0.21, 0.26, 0.38, 0.19, 0.21, 0.26, 0.38, 0.19, 0.21, 0.26, 0.38, 0.19, 0.21, 0.26, 0.38, 0.19, 0.21, 0.26, 0.38, 0.19, 0.21],
                    ['Solar', 0.21, 0.21, 0.21, 0.21, 0.21, 0.21, 0.21, 0.21, 0.21, 0.21, 0.21, 0.21, 0.21, 0.21, 0.21, 0.21, 0.21, 0.21, 0.21, 0.21, 0.21, 0.21, 0.21, 0.21, 0.21, 0.21],
                ]
            },
            xAxis: { type: 'category', name: 'Date',
            nameLocation: 'middle',
            nameGap: 30 },
            yAxis: { gridIndex: 0, name: 'Cost $', nameLocation:'middle', nameGap:30 },
            series: [
                { type: 'line', smooth: true, seriesLayoutBy: 'row' },
                { type: 'line', smooth: true, seriesLayoutBy: 'row' },
            ]
        }

    }

    getNetSolarEnergyData = () => {
        let { dashboardData } = this.state;
        return {
            tooltip: {
                trigger: 'axis'
            },
            legend: {
                data: ['Solar Deposited', 'Solar Withdrawn']
            },
            calculable: true,
            xAxis: [
                {
                    type: 'category',
                    data: _.get(dashboardData, 'net_solar_energy_produced_consumed', []).map((oData) => {
                        return _.get(oData, 'date');
                    }),
                    name: 'Date',
                    nameLocation: 'middle',
                    nameGap: 50
                }
            ],
            yAxis: [
                {
                    type: 'value',
                    name: 'Energy [KWh]',
                    nameLocation: 'middle',
                    nameGap: 50
                }
            ],
            series: [
                {
                    name: 'Solar Deposited',
                    type: 'bar',
                    data: _.get(dashboardData, 'net_solar_energy_produced_consumed', []).map((oData) => {
                        return _.get(oData, 'Solar Deposited');
                    }),
                    itemStyle: {
                        color: '#2e3192'
                    }
                },
                {
                    name: 'Solar Withdrawn',
                    type: 'bar',
                    data: _.get(dashboardData, 'net_solar_energy_produced_consumed', []).map((oData) => {
                        return _.get(oData, 'Solar Withdrawn');
                    }),
                    itemStyle: {
                        color: '#5f5f5f'
                    }
                }
            ]
        };

    }
    getBillingInsight = () => {
        let { dashboardData } = this.state;
        return {
            tooltip: {
                trigger: 'axis',
                // }
            },
            toolbox: {
                feature: {
                    saveAsImage: { show: true }
                }
            },
            legend: {
                data: ['Electric', 'Solar', 'Total']
            },
            xAxis: [
                {
                    type: 'category',
                    data: _.get(dashboardData, 'bill_details', []).map((oData) => {
                        return _.get(oData, 'date');
                    }),
                    axisPointer: {
                        type: 'shadow'
                    }
                }
            ],
            yAxis: [
                {
                    type: 'value',
                    name: '水量',
                    min: 0,
                    max: 250,
                    // interval: 50,
                    // axisLabel: {
                    //     formatter: '{value} ml'
                    // }
                },
                {
                    type: 'value',
                    name: '温度',
                    // min: 0,
                    // max: 25,
                    // interval: 5,
                    // axisLabel: {
                    //     // formatter: '{value} °C'
                    // }
                }
            ],
            series: [
                {
                    name: 'Electric',
                    type: 'bar',
                    data: _.get(dashboardData, 'bill_details', []).map((oData) => {
                        return _.get(oData, 'Electric');
                    })
                },
                {
                    name: 'Solar',
                    type: 'bar',
                    data: _.get(dashboardData, 'bill_details', []).map((oData) => {
                        return _.get(oData, 'Solar');
                    })
                },
                {
                    name: 'Total',
                    type: 'line',
                    yAxisIndex: 1,
                    data: _.get(dashboardData, 'bill_details', []).map((oData) => {
                        return _.get(oData, 'Total');
                    })
                }
            ]
        };
    }

    getHighEnergyUsage = () => {
        return {
            dataset: {
                source: [
                    ['Usage', 'product'],
                    [89.3, 'Air Conditioning'],
                    [57.1, 'Cooking Range'],
                    [74.4, 'Washer & Dryer'],
                    [50.1, 'Refridgerator'],
                ]
            },
            grid: { containLabel: true },
            xAxis: { name: 'amount' },
            yAxis: { type: 'category' },
            visualMap: {
                orient: 'horizontal',
                left: 'center',
                min: 10,
                max: 100,
                text: ['High Usage', 'Low Usage'],
                // Map the score column to color
                dimension: 0,
                inRange: {
                    color: ['#D7DA8B', '#E15457']
                }
            },
            series: [
                {
                    type: 'bar',
                    encode: {
                        // Map the "amount" column to X axis.
                        x: 'amount',
                        // Map the "product" column to Y axis
                        y: 'product'
                    }
                }
            ]
        };
    }
    getSolarTotalBenifits = () => {
        let { dashboardData } = this.state;
        return {
            tooltip: {
                trigger: 'axis',
            },
            legend: {
                data: ['Solar']
            },
            xAxis: {
                type: 'category',
                boundaryGap: false,
                data: _.get(dashboardData, 'solar_total_benifits', []).map((oData) => {
                    return _.get(oData, 'date');
                }),
                name: 'Date',
                nameLocation: 'middle',
                nameGap: 50
                // data: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
            },
            yAxis: {
                // type: 'value'
                name: 'Benefit in $',
                nameLocation: 'middle',
                nameGap: 50
            },
            series: [{
                // data: [820, 932, 901, 934, 1290, 1330, 1320],
                data: _.get(dashboardData, 'solar_total_benifits', []).map((Data) => {
                    return _.get(Data, 'Solar Total Benefits');
                }),
                type: 'line',
                itemStyle: {
                    color: '#5f5f5f'
                }
            }]
        };

    }

    handleFetchData = () => {
        this.props.getEnergyScannerData(this.state.month);
    }

    handleRouteToLogin = () => {
        if (this.state.redirect) {
            return this.props.history.push('/');
        }
    }

    render() {
        let { type, dashboardData, errorMessage, loader, month } = this.state;
        return (
            <div>
                {this.handleRouteToLogin()}
                <div>
                    {loader && <Preloader />}
                    {/*loader end*/}
                    <div className="container-fluid">
                        {/* Begin page */}
                        <div id="layout-wrapper">
                            <TopHeader onSignOut={() => this.props.signOut()} />
                            <SideVerticalNav />
                            {/* ============================================================== */}
                            {/* Start right Content here */}
                            {/* ============================================================== */}
                            <div className="main-content">
                                <div className="page-content">
                                    {/* start page title */}
                                    <div className="row">
                                        <div className="col-12">
                                            <div className="page-title-box d-flex align-items-center justify-content-between">
                                                <h4 className="page-title mb-0 font-size-18">GXG AI - Energy Scanner</h4>
                                                <div className="page-title-right">
                                                    <ol className="breadcrumb m-0">
                                                        <li className="breadcrumb-item"><a href="javascript: void(0);">Powered by our
                        cutting edge AI engine, running on GXG AI platform</a></li>
                                                    </ol>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    {/* end page title */}
                                    <div className="row">
                                        <div className="col-md-9 align-right">
                                            <p style={{ color: '#283D92' }}>Data for the Month of :   {_.get(dashboardData, 'usage_efficiency_percentage.month_name', 'January')} </p>
                                        </div>
                                        <div className="col-md-3">
                                            <div className="form-group">
                                                <select className="form-control" id="exampleFormControlSelect1" value={_.get(dashboardData, 'usage_efficiency_percentage.month_name', 'January')}
                                                    onChange={(e) => this.setState({ month: e.target.value }, () => this.handleFetchData())}>
                                                    <option value="January">January</option>
                                                    <option value="February">February</option>
                                                    <option value="March">March</option>
                                                    <option value="April">April</option>
                                                    <option value="May">May</option>
                                                    <option value="June">June</option>
                                                    <option value="July">July</option>
                                                    <option value="August">August</option>
                                                    <option value="September">September</option>
                                                    <option value="October">October</option>
                                                    <option value="November">November</option>
                                                    <option value="December">December</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="row">
                                        <div className="col-md-3">
                                            <div className="card">
                                                <div className="card-body">
                                                    <p className="mb-2" style={{ whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}><i className="bx bx-dollar font-size-24 align-middle mr-1" style={{ color: '#001148' }} /> Total Bill</p>
                                                    <h4 className="mb-0" style={{ color: '#2e3192' }}>${_.get(dashboardData, 'usage_efficiency_percentage.Current Bill', '')}</h4>
                                                    {/* <span className="badge badge-soft-info mr-2">6.5% less than Apr bill<i className="mdi mdi-arrow-up ml-1" />
                                                    </span> */}
                                                </div>
                                            </div>
                                        </div>
                                        <div className="col-md-3">
                                            <div className="card">
                                                <div className="card-body">
                                                    <p className="mb-2" style={{ whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}><i className="bx bx-dollar font-size-24 align-middle mr-1" style={{ color: '#001148' }} />Electric Power</p>
                                                    <h4 className="mb-0" style={{ color: '#2e3192' }}>${_.get(dashboardData, 'usage_efficiency_percentage.Electric Bill', '')}</h4>
                                                    <div style={{ color: '#6542C7' }}>
                                                        {/* <span className="badge badge-soft-primary mr-2">19.8% less than Apr usage<i className="mdi mdi-arrow-down ml-1" />
                                                        </span> */}
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="col-md-3">
                                            <div className="card">
                                                <div className="card-body">
                                                    <p className="mb-2" style={{ whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}><i className="bx bx-dollar font-size-24 align-middle mr-1" style={{ color: '#001148' }} />Solar Power</p>
                                                    <h4 className="mb-0" style={{ color: '#2e3192' }}>${_.get(dashboardData, 'usage_efficiency_percentage.Solar Power', '')}</h4>
                                                    {/* <span className="badge badge-soft-warning mr-2">6.9% more than Apr usage<i className="mdi mdi-arrow-up ml-1" />
                                                    </span> */}
                                                </div>
                                            </div>
                                        </div>
                                        <div className="col-md-3">
                                            <div className="card">
                                                <div className="card-body">
                                                    <p className="mb-2" style={{ whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}><i className="bx bx-dollar font-size-24 align-middle mr-1" style={{ color: '#001148' }} /> Your Savings</p>
                                                    <h4 className="mb-0" style={{ color: '#2e3192' }}>${_.get(dashboardData, 'usage_efficiency_percentage.Your Savings', '')}</h4>
                                                    {/* <span className="badge badge-soft-info mr-2">6.5% less than Apr bill<i className="mdi mdi-arrow-up ml-1" />
                                                    </span> */}
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="row">
                                        <div className="col-lg-8">
                                            <div className="card">
                                                <div className="card-body">
                                                    <h4 className="card-title mb-4" style={{ color: '2e3192' }}>Overall Usage Insights</h4>
                                                    <Chart
                                                        // width={'500px'}
                                                        height={'300px'}
                                                        chartType="ComboChart"
                                                        loader={<div>Loading Chart</div>}
                                                        data={this.overAllUsage()}
                                                        options={{
                                                            vAxis: { title: 'Energy [KWh]' },
                                                            hAxis: { title: 'Date' },
                                                            seriesType: 'bars',
                                                            series: { 2: { type: 'line' } },
                                                            colors: ['#2e3192', '#5f5f5f', '#6d0000'],
                                                            isStacked: true
                                                        }}
                                                        rootProps={{ 'data-testid': '1' }}
                                                    />
                                                </div>
                                            </div>
                                            {/*end card*/}
                                        </div>
                                        <div className="col-lg-4">
                                            <div className="card">
                                                <div className="card-body">
                                                    <h4 className="card-title mb-4">Solar Electric Usage</h4>
                                                    <ReactEcharts option={this.getSolarElectricUsage()} />
                                                </div>
                                            </div>
                                            {/*end card*/}
                                        </div>
                                    </div>
                                    {/* end row */}
                                    <h4 style={{ color: '#2e3192' }}>Solar Energy Usage Insights</h4>
                                    <div className="row">
                                        <div className="col-xl-3">
                                            <div className="card">
                                                <div className="card-body">
                                                    <div className="row">
                                                        <div className="col-12">
                                                        <p style={{ whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}><i className="dripicons-battery-full font-size-20 align-middle mr-1" style={{ color: '#001148' }} />Solar Power Deposited [KWh]</p>
                                                        </div>
                                                        <div className="row col-md-12">
                                                            <div className="col-7">
                                                                <p style={{ fontWeight: 'bold', color: '#2e3192', fontSize: '15.5px', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{_.get(dashboardData, 'solar_energy_usage_insights.Solar Power Produced', '')}</p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="card">
                                                <div className="card-body">
                                                    <div className="row">
                                                        <div className="col-12">
                                                        <p style={{ whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}><i className="dripicons-battery-full font-size-20 align-middle mr-1" style={{ color: '#001148' }} />Solar Power Withdrawn [KWh]</p>
                                                        </div>
                                                        <div className="row col-md-12">
                                                            <div className="col-7">
                                                                <p style={{ fontWeight: 'bold', color: '#2e3192', fontSize: '15.5px', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{_.get(dashboardData, 'solar_energy_usage_insights.Solar Power Consumed', '')}</p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="card">
                                                <div className="card-body">
                                                    <div className="row">
                                                        <div className="col-12">
                                                            <i className="fas fa-leaf font-size-20 align-middle mr-1" style={{ color: '#42C782', }} />Green Efficiency<p />
                                                        </div>
                                                        <div className="row col-md-12">
                                                            <div className="col-5">
                                                                <p style={{ fontWeight: 'bold', color: '#2e3192', fontSize: '15.5px', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{_.get(dashboardData, 'solar_energy_usage_insights.Solar Efficiency', '')} %</p>
                                                            </div>
                                                            <div className="col-7">
                                                                <div style={{ color: '#61D097' }}>
                                                                    <p style={{ fontSize: '12px', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}><i className="bx bxs-like ml-1" />Nothing to worry about</p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="col-xl-3">
                                            <div className="card">
                                                <div className="card-body">
                                                    <div className="row">
                                                        <div className="col-12" style={{ margin: 5 }}>
                                                            <p style={{ whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}><i className="fas fa-dollar-sign font-size-20 align-middle mr-1" style={{ color: '#429BC7' }} />Solar Deposit Rate / AC [KWh]</p>
                                                        </div>
                                                        <div className="row col-md-12">
                                                            <div className="col-7">
                                                                <p style={{ fontWeight: 'bold', color: '#2e3192', fontSize: '15.5px', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>${_.get(dashboardData, 'solar_energy_usage_insights.Solar Purchase Price', '')}</p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="card">
                                                <div className="card-body">
                                                    <div className="row">
                                                        <div className="col-12">
                                                            <p className="mb-2"><img style={{ width: 20, height: 20 }} src="assets/images/GXG.png" />GXG Debits [KWh]</p>
                                                        </div>
                                                        <div className="row col-md-12">
                                                            <div className="col-7">
                                                                <p style={{ fontWeight: 'bold', color: '#2e3192', fontSize: '15.5px', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{_.get(dashboardData, 'solar_energy_usage_insights.GXG-Debits', '')}</p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="card">
                                                <div className="card-body">
                                                    <div className="row">
                                                        <div className="col-12">
                                                            <p className="mb-2"><img style={{ width: 20, height: 20 }} src="assets/images/GXG.png" />GXG Credits [KWh]</p>
                                                        </div>
                                                        <div className="row col-md-12">
                                                            <div className="col-7">
                                                                <p style={{ fontWeight: 'bold', color: '#2e3192', fontSize: '15.5px', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{_.get(dashboardData, 'solar_energy_usage_insights.GXG-Credits', '')}</p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="col-xl-6">
                                            <div className="card">
                                                <div className="card-body">
                                                    <h4 className="card-title mb-4" style={{ color: '#2e3192', }}>Energy Cost/KWH</h4>
                                                    <ReactEcharts option={this.getEnergyCost()} />
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div className="row">
                                        <div className="col-xl-12">
                                            <div className="card">
                                                <div className="card-body">
                                                    <h4 className="card-title mb-4" style={{ color: '#2e3192', }}>Billing Details & Insights</h4>
                                                    {/* <ReactEcharts option={this.getBillingInsight()} /> */}
                                                    <Chart
                                                        // width={'500px'}
                                                        height={'300px'}
                                                        chartType="ComboChart"
                                                        loader={<div>Loading Chart</div>}
                                                        data={this.bill_details()}
                                                        options={{
                                                            // title: 'Monthly Coffee Production by Country',
                                                            vAxis: { title: 'Amount in $' },
                                                            hAxis: { title: 'Date' },
                                                            seriesType: 'bars',
                                                            series: { 2: { type: 'line' } },
                                                            colors: ['#2e3192', '#5f5f5f', '#6d0000'],
                                                            isStacked: true
                                                        }}
                                                        rootProps={{ 'data-testid': '1' }}
                                                    />
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="row">
                                        <div className="col-xl-6">
                                            <div className="card">
                                                <div className="card-body">
                                                    <h4 className="card-title mb-4" style={{ color: '#2e3192', }}>Net Solar Energy Deposited & Withdrawn</h4>
                                                    <ReactEcharts option={this.getNetSolarEnergyData()} />
                                                </div>
                                            </div>
                                        </div>
                                        <div className="col-xl-6">
                                            <div className="card">
                                                <div className="card-body">
                                                    <h4 className="card-title mb-4" style={{ color: '#2e3192', }}>Solar Total Benefits</h4>
                                                    <ReactEcharts option={this.getSolarTotalBenifits()} />
                                                </div>
                                            </div>
                                        </div>
                                        {/* <div className="col-xl-6">
                                            <div className="card">
                                                <div className="card-body">
                                                    <h4 className="card-title mb-4">High Energy Usage</h4>
                                                    <ReactEcharts option={this.getHighEnergyUsage()} />
                                                </div>
                                            </div>
                                        </div> */}
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    {/* end row */}
                </div>
            </div>
        )
    }
};

function mapStateToProps(state) {
    return {
        type: state.DashboardReducer.type,
        dashboardData: state.DashboardReducer.dashboardData,
        isRequesting: state.DashboardReducer.isRequesting,
        errorMessage: state.DashboardReducer.message,
        authType: state.AuthReducer.type
    }
}

function mapDisptchToProps(dispatch) {
    return bindActionCreators(ActionCreators, dispatch);
}

export default connect(mapStateToProps, mapDisptchToProps)(Dashboard);