import React from 'react';
import Preloader from '../../Components/Preloader';
import { connect } from 'react-redux';
import { ActionCreators } from '../../Actions';
import { bindActionCreators } from 'redux';
import * as ActionTypes from '../../Actions/ActionTypes';
import _ from 'lodash';
import StripePayment from '../../Utils/StripePayment';
import { Link } from 'react-router-dom';

class Payment extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            loader: false, docData: {}, type: undefined
        }
        this.userData = JSON.parse(localStorage.getItem('userData'));
        this.docData = JSON.parse(localStorage.getItem('docData'));
    }

    handleClick = () => {
        this.props.getCheckoutId({ email: _.get(this.docData, 'email'), unit_amount: _.size(_.get(this.docData, 'documents', 1)) });
        // this.props.getCheckoutId({ email: _.get(this.props, 'docData.email'), unit_amount: _.size(_.get(this.props, 'docData.documents', 1)) });
    }

    static getDerivedStateFromProps(nextProps, state) {
        if (state.type !== nextProps.state) {
            if (nextProps.type === ActionTypes.GET_CHECKOUTID_PENDING || nextProps.type === ActionTypes.GET_CHECKOUTID_FAILURE || nextProps.type === ActionTypes.GET_CHECKOUTID_SUCCESS) {
                return {
                    loader: nextProps.isRequesting, type: nextProps.type
                }
            }
        }
        return null;
    }

    componentDidUpdate(prevProps) {
        if (this.props.type !== prevProps.type && this.props.type === ActionTypes.GET_CHECKOUTID_SUCCESS) {
            StripePayment.proceedToPayment(this.props.checkoutData.id);
        }
    }


    render() {
        let { loader } = this.state;
        // console.log(this.props.userData, this.props.type);
        return (
            <div>
                <div>
                    {/*loader start*/}
                    {loader && <Preloader />}
                    {/*loader end*/}
                    {/*body content wrap start*/}
                    <div className="main">
                        {/*hero section start*/}
                        <section className="hero-section ptb-100 gradient-overlay full-screen" style={{ background: 'url("assets/images/project-details.jpg")no-repeat center center / cover' }}>
                            <div className="container">
                                <div className="row align-items-center justify-content-between pt-5 pt-sm-5 pt-md-5 pt-lg-0">
                                    <div className="col-md-7 col-lg-6">
                                        <div className="hero-content-left text-white">
                                            <a className="navbar-brand" href="#">
                                                <img src="../../assets/images/logo-white.png" width={160} alt="logo" className="img-fluid" />
                                            </a>
                                            <h1 className="text-white">PAYMENT</h1>
                                            <p className="lead">Payment</p>
                                        </div>
                                    </div>
                                    <div className="col-md-5 col-lg-5">
                                        <div className="card login-signup-card shadow-lg mb-0">
                                            <div className="card-body px-md-5 py-5">
                                                <div className="mb-5"></div>
                                                {/*login form*/}
                                                <div className="form-group">
                                                    <input name="email" type="email" className="form-control" placeholder="Amount to be Paid" readOnly value={_.get(this.docData, 'email')} />
                                                    <input name="email" type="email" className="form-control" readOnly placeholder="Enter Amount" value={`$${_.size(_.get(this.docData, 'documents', 1))}`} />
                                                    <button onClick={() => this.handleClick()} type="submit" className="btn btn-block solid-btn border-radius mt-4 mb-3">Pay</button>
                                                    <img src={'/assets/images/payments.jpeg'} className="img-responsive" style={{width:'150px'}}/>
                                                    {/* <button onClick={() => this.props.history.push('/register/paymentstatus')} type="submit" className="btn btn-block solid-btn border-radius mt-4 mb-3">Pay</button> */}
                                                </div>
                                                <div className="card-footer bg-transparent border-top px-md-5">
                                                    <small>GO to GXG Family?</small>
                                                    <Link to="/" className="small"> Login</Link>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="shape-bottom">
                                    <img src="../../assets/images/hero-shape-bottom.svg" alt="shape" className="bottom-shape img-fluid" />
                                </div>
                            </div></section>
                        {/*hero section end*/}
                    </div>
                </div>
            </div>
        );
    }
};

function mapStateToProps(state) {
    return {
        userData: state.AuthReducer.userData,
        docData: state.AuthReducer.docData,
        type: state.AuthReducer.type,
        isRequesting: state.AuthReducer.isRequesting,
        checkoutData: state.AuthReducer.checkoutData
    }
}

function mapDispatchToProps(dispatch) {
    return bindActionCreators(ActionCreators, dispatch);
}


export default connect(mapStateToProps, mapDispatchToProps)(Payment);