import React from 'react';
import Preloader from '../../Components/Preloader';
import { connect } from 'react-redux';
import { ActionCreators } from '../../Actions';
import { bindActionCreators } from 'redux';
import * as ActionTypes from '../../Actions/ActionTypes';
import _ from 'lodash';
import asyncLocalStorage from '../../Utils/asyncLocalStorage';
import { Link } from 'react-router-dom';


class Docusign extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            loader: false, docData: {}
        }
    }

    onSubmitHandler = () => {
        this.props.getStatus(_.get(this.props, 'userData.subscriber_id', ''));
    }

    static getDerivedStateFromProps(nextProps, state) {
        console.log(nextProps.type);
        if (nextProps.type !== state.type) {
            if (nextProps.type === ActionTypes.POST_DOCUSIGN_PENDING) {
                return { loader: true }
            } else if (nextProps.type === ActionTypes.POST_DOCUSIGN_SUCCESS) {
                return {
                    docData: nextProps.docData
                }
            }
        }
        return null;
    }

    componentDidUpdate(prevProps) {
        if (this.props.type === ActionTypes.POST_DOCUSIGN_SUCCESS && prevProps.type !== this.props.type) {
            // console.log(this.props.docData);
            localStorage.setItem('userData', JSON.stringify(this.props.userData));
            localStorage.setItem('docData', JSON.stringify(this.props.docData));
            window.location = _.get(this.props, 'docData.redirect_url');
        }
    }



    render() {
        let { loader } = this.state;
        // console.log(this.props.userData, this.props.type);
        return (
            <div>
                <div>
                    {/*loader start*/}
                    {/* {loader && <Preloader />} */}
                    {/*loader end*/}
                    {/*body content wrap start*/}
                    <div className="main">
                        {/*hero section start*/}
                        <section className="hero-section ptb-100 gradient-overlay full-screen" style={{ background: 'url("assets/images/project-details.jpg")no-repeat center center / cover' }}>
                            <div className="container">
                                <div className="row align-items-center justify-content-between pt-5 pt-sm-5 pt-md-5 pt-lg-0">
                                    <div className="col-md-7 col-lg-6">
                                        <div className="hero-content-left text-white">
                                            <a className="navbar-brand" href="#">
                                                <img src="../../assets/images/logo-white.png" width={160} alt="logo" className="img-fluid" />
                                            </a>
                                            <h1 className="text-white">AGREEMENT</h1>
                                            <p className="lead">REVIEW &nbsp; SIGN THE CUSTOMER AGREEMENT</p>
                                            <p className="lead">This overall agreement between GXG Energy LLC <br />and the customer covers:
                                            </p>
                                            1. The Solar PPA Agreement<br />
                                            2. The Battery Lease Agreement<br />
                                            3. The Air Rights Lease<br />
                                            4. The Land Lease and Solar Easement Agreement<br />
                                        </div>
                                    </div>
                                    <div className="col-md-5 col-lg-5">
                                        <div className="card login-signup-card shadow-lg mb-0">
                                            <div className="card-body px-md-5 py-5">
                                                <div className="mb-5"></div>
                                                {/*login form*/}
                                                <div className="form-group">
                                                    <img src="../../assets/images/agreement.png" />
                                                    {/* Submit */}
                                                    <button onClick={() => this.onSubmitHandler()} className="btn btn-block solid-btn border-radius mt-4 mb-3"> {loader ? <i className="fas fa-spinner fa-spin fa-lg" ></i> : "Review & Sign"}</button>
                                                </div>
                                                <div className="card-footer bg-transparent border-top px-md-5">
                                                    <small>GO to GXG Family?</small>
                                                    <Link to="/" className="small"> Login</Link>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="shape-bottom">
                                    <img src="../../assets/images/hero-shape-bottom.svg" alt="shape" className="bottom-shape img-fluid" />
                                </div>
                            </div></section>
                        {/*hero section end*/}
                    </div>
                </div>


            </div>
        );
    }
};

function mapStateToProps(state) {
    return {
        type: state.AuthReducer.type,
        userData: state.AuthReducer.userData,
        docData: state.AuthReducer.docData
    }
}

function mapDispatchToProps(dispatch) {
    return bindActionCreators(ActionCreators, dispatch);
}

export default connect(mapStateToProps, mapDispatchToProps)(Docusign);