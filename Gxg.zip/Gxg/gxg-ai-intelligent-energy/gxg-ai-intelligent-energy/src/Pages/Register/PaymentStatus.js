import React, { Component } from 'react'
import { Link } from 'react-router-dom';
import Preloader from '../../Components/Preloader';
import { connect } from 'react-redux';
import { ActionCreators } from '../../Actions';
import { bindActionCreators } from 'redux';
import * as ActionTypes from '../../Actions/ActionTypes';
import _ from 'lodash';


class PaymentStatus extends Component {
  constructor(props) {
    super(props);
    this.state = {
      loader: false, type:undefined
    }
    this.urlParams = new URLSearchParams(window.location.search);
  }

  componentDidMount() {
    const userData = JSON.parse(localStorage.getItem('userData'));
    const docData = JSON.parse(localStorage.getItem('docData'));
    setTimeout(() => {
      this.props.paymentReporting(userData.subscriber_id, this.urlParams.get('status'))
    }, 3000);

    // setTimeout(() => {
    //   this.props.history.push('/');
    // }, 8000)
  }

  static getDerivedStateFromProps(nextProps, state) {
    if (state.type !== nextProps.state) {
      if (nextProps.type === ActionTypes.POST_PAYMENT_REPORTING_FAILURE || nextProps.type === ActionTypes.POST_PAYMENT_REPORTING_PENDING || nextProps.type === ActionTypes.POST_PAYMENT_REPORTING_SUCCESS) {
        return {
          loader: nextProps.isRequesting, type: nextProps.type
        }
      }
    }
    return null;
  }

  componentDidUpdate(prevProps) {
    if (this.props.type !== prevProps.type && this.props.type === ActionTypes.POST_PAYMENT_REPORTING_SUCCESS) {
      localStorage.clear();
      this.handleRedirect();
    }
  }

  handleRedirect = () => {
    this.props.history.push('/login')
  }

  render() {
    //http://localhost:3000/register/paymentstatus?status=success
    const { loader } = this.state;
    let displayText = '';
    if (this.urlParams.get('status') === 'success') {
      displayText = 'Received Your Payment Successfully. Please wait the page will be redirected.';
    } else {
      displayText = 'Your Transaction is Cancelled';
    }
    return (
      <div className="main">
        {loader && <Preloader />}
        {/*hero section start*/}
        <section className="hero-section ptb-100 gradient-overlay full-screen" style={{ background: 'url("assets/images/project-details.jpg")no-repeat center center / cover' }}>
          <div className="container">
            <div className="row align-items-center justify-content-between pt-5 pt-sm-5 pt-md-5 pt-lg-0">
              <div className="col-md-7 col-lg-12">
                <div className="hero-content-left text-white">
                  <Link className="navbar-brand" to="/">
                    <img src="../../assets/images/logo-white.png" width={160} alt="logo" className="img-fluid" />
                  </Link>
                  <h1 className="text-white"><i className={`fas ${this.urlParams.get('status') === 'success' ? 'fa-check-circle' : 'fa-exclamation-triangle'}`}></i>{' ' + displayText}</h1>
                </div>
              </div>
            </div>
            <div className="shape-bottom">
              <img src="../../assets/images/hero-shape-bottom.svg" alt="shape" className="bottom-shape img-fluid" />
            </div>
          </div></section>
        {/*hero section end*/}
      </div>
    )
  }
}

function mapStateToProps(state) {
  return {
    isRequesting: state.AuthReducer.isRequesting,
    type: state.AuthReducer.type
  }
}

function mapDispatchToProps(dispatch) {
  return bindActionCreators(ActionCreators, dispatch);
}

export default connect(mapStateToProps, mapDispatchToProps)(PaymentStatus);
