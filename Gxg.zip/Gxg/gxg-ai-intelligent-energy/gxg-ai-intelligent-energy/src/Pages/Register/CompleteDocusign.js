import React, { Component } from 'react'
import { Link } from 'react-router-dom';
import { connect } from 'react-redux';
import { ActionCreators } from '../../Actions';
import { bindActionCreators } from 'redux';
import * as ActionTypes from '../../Actions/ActionTypes';
import _ from 'lodash';
import Preloader from '../../Components/Preloader';
import asyncLocalStorage from '../../Utils/asyncLocalStorage';

class CompleteDocusign extends Component {
  constructor(props) {
    super(props);
    this.state = {
      type: undefined, loader: false
    }
  }
  componentDidMount() {
    const urlParams = new URLSearchParams(window.location.search);
    let userData = JSON.parse(localStorage.getItem('userData'));
    let docData = JSON.parse(localStorage.getItem('docData'));
    //   console.log(this.props, docData, userData);
    let reqObj = { documents: _.get(docData, 'documents', []), envelope_id: _.get(docData, 'envelope_id', ''), subscriber_id: _.get(userData, 'subscriber_id', '') };
    if (_.get(reqObj, 'envelope_id') && _.get(reqObj, 'subscriber_id',) && _.get(docData, 'documents') && urlParams.get('event') === 'signing_complete') {
      this.props.docuSignSuccess(reqObj);
    } else if (urlParams.get('event') === 'decline') {
      localStorage.clear();
      setTimeout(() => {
        this.props.history.push('/');
      }, 4000)
    }
  }

  static getDerivedStateFromProps(nextProps, state) {
    if (state.type !== nextProps.state) {
      if (nextProps.type === ActionTypes.PUT_DOCUSIGN_PENDING || nextProps.type === ActionTypes.PUT_DOCUSIGN_FAILURE || nextProps.type === ActionTypes.PUT_DOCUSIGN_SUCCESS) {
        return {
          loader: nextProps.isRequesting, type: nextProps.type
        }
      }
    }
    return null;
  }

  componentDidUpdate(prevProps) {
    if (this.props.type !== prevProps.type && this.props.type === ActionTypes.PUT_DOCUSIGN_SUCCESS) {
      this.handleRedirect();
    }
  }

  handleRedirect = () => {
    this.props.history.push('/register/payment')
  }

  render() {
    const urlParams = new URLSearchParams(window.location.search);
    let displayText = '';
    if (urlParams.get('event') === 'signing_complete') {
      displayText = 'Your Document has been successfully signed';
    } else {
      displayText = 'Your Docusign has been Rejected';
    }
    let { loader } = this.state;
    return (
      <div className="main">
        {loader && <Preloader />}
        {/*hero section start*/}
        <section className="hero-section ptb-100 gradient-overlay full-screen" style={{ background: 'url("assets/images/project-details.jpg")no-repeat center center / cover' }}>
          <div className="container">
            <div className="row align-items-center justify-content-between pt-5 pt-sm-5 pt-md-5 pt-lg-0">
              <div className="col-md-7 col-lg-12">
                <div className="hero-content-left text-white">
                  <Link className="navbar-brand" to="/">
                    <img src="../../assets/images/logo-white.png" width={160} alt="logo" className="img-fluid" />
                  </Link>
                  <h1 className="text-white">{displayText}</h1>
                </div>
              </div>
            </div>
            <div className="shape-bottom">
              <img src="../../assets/images/hero-shape-bottom.svg" alt="shape" className="bottom-shape img-fluid" />
            </div>
          </div>
        </section>
        {/*hero section end*/}
      </div>
    )
  }
}

function mapStateToProps(state) {
  return {
    userData: state.AuthReducer.userData,
    docData: state.AuthReducer.docData,
    type: state.AuthReducer.type,
    isRequesting: state.AuthReducer.isRequesting
  }
}

function mapDispatchToProps(dispatch) {
  return bindActionCreators(ActionCreators, dispatch);
}

export default connect(mapStateToProps, mapDispatchToProps)(CompleteDocusign);
