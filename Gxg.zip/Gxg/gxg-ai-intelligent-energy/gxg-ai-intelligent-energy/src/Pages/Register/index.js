import React from 'react';
import Preloader from '../../Components/Preloader';
import { Link } from 'react-router-dom';
import { connect } from 'react-redux';
import { ActionCreators } from '../../Actions';
import { bindActionCreators } from 'redux';
import * as ActionTypes from '../../Actions/ActionTypes';
import { Formik, Form, ErrorMessage } from "formik";
import _ from 'lodash';
import SweetAlert from 'react-bootstrap-sweetalert';


class Register extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            currentStep: 0, type: undefined, isRequesting: false, message: '', userData: {}, redirect: false, reqType: ''
        }
        this.formRef = React.createRef();
    }

    handleForm = (errors) => {
        let { values: { full_name, email, phone, passwd, repeat_passwd } } = this.formRef.current;
        if (!_.get(errors, 'full_name') && !_.get(errors, 'email') && !_.get(errors, 'phone') && !_.get(errors, 'passwd') && !_.get(errors, 'repeat_passwd')) {
            this.setState(prevState => ({ currentStep: prevState.currentStep + 1 }));
        }
        // if (full_name, email, phone, passwd, repeat_passwd) {
        //     this.setState(prevState => ({ currentStep: prevState.currentStep + 1 }));
        // }
    }
    stepOne = (handleChange, handleBlur, values, errors) => {
        const emailTest = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/i;
        // let {errors} = this.formRef.current;
        // console.log(errors);
        return (
            <React.Fragment>
                <div className="card-body px-md-5 py-5">
                    <div className="mb-5">
                        <h5 className="h3">Sign Up</h5>
                        <p className="text-muted mb-0">Create Account.</p>
                    </div>
                    {/*login form*/}
                    {/* <form className="login-signup-form"> */}
                    <div className="form-group">
                        <label className="pb-1">Your Name</label>
                        <input type="text" className={`form-control ${_.get(errors, 'full_name') ? 'is-invalid' : ''}`} value={values.full_name} placeholder="Enter Exactly as in your Utility Bill" onChange={handleChange} name="full_name" onBlur={handleBlur} />
                        <div className="invalid-feedback">
                            {_.get(errors, 'full_name')}
                        </div>
                    </div>
                    {/* Password */}
                    <div className="form-group">
                        <div className="row">
                            <div className="col">
                                <label className="pb-1">Your Email</label>
                            </div>
                        </div>
                        <input type="email" className={`form-control ${_.get(errors, 'email') ? 'is-invalid' : ''}`} value={values.email} placeholder="Enter Your Email" onChange={handleChange} name="email" onBlur={handleBlur} />
                        <div className="invalid-feedback">
                            {_.get(errors, 'email')}
                        </div>
                    </div>
                    {/* Phone */}
                    <div className="form-group">
                        <div className="row">
                            <div className="col">
                                <label className="pb-1">Your Phone No.</label>
                            </div>
                        </div>
                        <input type="Phone" className={`form-control ${_.get(errors, 'phone') ? 'is-invalid' : ''}`} value={values.phone.replace(/(\d{3})(\d{3})(\d{4})/, "($1)-$2-$3")} placeholder="Enter Your Phone No." onChange={handleChange} name="phone" onBlur={handleBlur} />
                        <div className="invalid-feedback">
                            {_.get(errors, 'phone')}
                        </div>
                    </div>
                    {/* Password */}
                    <div className="form-group">
                        <div className="row">
                            <div className="col">
                                <label className="pb-1">Create Password</label>
                            </div>
                        </div>
                        <input type="password" className={`form-control ${_.get(errors, 'passwd') ? 'is-invalid' : ''}`} value={values.passwd} placeholder="Enter Your password" onChange={handleChange} name="passwd" onBlur={handleBlur} />
                        <div className="invalid-feedback">
                            {_.get(errors, 'passwd')}
                        </div>
                    </div>
                    <div className="form-group">
                        <div className="row">
                            <div className="col">
                                <label className="pb-1">Confirm Password</label>
                            </div>
                        </div>
                        <input type="password" className={`form-control ${_.get(errors, 'repeat_passwd') ? 'is-invalid' : ''}`} value={values.repeat_passwd} placeholder="Confirm password" onChange={handleChange} name="repeat_passwd" onBlur={handleBlur} />
                        <div className="invalid-feedback">
                            {_.get(errors, 'repeat_passwd')}
                        </div>
                    </div>
                    {/* Submit */}
                    <button className="btn btn-block solid-btn border-radius mt-4 mb-3" onClick={() => this.handleForm(errors)}>Next</button>
                </div>
                <div className="card-footer bg-transparent border-top px-md-5"><small>GO to GXG Family?</small>
                    <Link to="/" className="small"> Login</Link>
                </div>
            </React.Fragment>
        );
    }

    stepTwo = (handleChange, handleBlur, values, errors) => {
        let { isRequesting } = this.state;
        return (
            <div className="card-body px-md-5 py-5">
                {/* <form className="login-signup-form"> */}
                <div className="form-group">
                    <label className="pb-1">I'm the Homeowner</label>
                    <br />
                    <input type="radio" defaultValue="Yes" className={`${_.get(errors, 'home_owner') ? 'is-invalid' : ''}`} onChange={handleChange} name="home_owner" onBlur={handleBlur} checked={_.get(values, 'home_owner') === 'Yes'} />
                    <label htmlFor="male">Yes</label>
                    <input type="radio" defaultValue="No" className={`${_.get(errors, 'home_owner') ? 'is-invalid' : ''}`} onChange={handleChange} name="home_owner" onBlur={handleBlur} checked={_.get(values, 'home_owner') === 'No'} />
                    <label htmlFor="female">No</label>
                    <div className="invalid-feedback">
                        {_.get(errors, 'home_owner')}
                    </div>
                </div>
                {/* </form> */}
                {/* <form class="login-signup-form"> */}
                <div className="form-group">
                    <label className="pb-1">I own an electric vehicle</label>
                    <br />
                    <input type="radio" defaultValue="Yes" className={`${_.get(errors, 'electric_vehicle') ? 'is-invalid' : ''}`} onChange={handleChange} name="electric_vehicle" onBlur={handleBlur} checked={_.get(values, 'electric_vehicle') === 'Yes'} />
                    <label htmlFor="male">Yes</label>
                    <input type="radio" defaultValue="No" className={`${_.get(errors, 'electric_vehicle') ? 'is-invalid' : ''}`} onChange={handleChange} name="electric_vehicle" onBlur={handleBlur} checked={_.get(values, 'electric_vehicle') === 'No'} />
                    <label htmlFor="female">No</label>
                    <div className="invalid-feedback">
                        {_.get(errors, 'electric_vehicle')}
                    </div>
                </div>
                {/* <form class="login-signup-form"> */}
                <div className="form-group">
                    <label className="pb-1">I have existing solar panels</label>
                    <br />
                    <input type="radio" defaultValue="Yes" className={`${_.get(errors, 'ext_solar_panel') ? 'is-invalid' : ''}`} onChange={handleChange} name="ext_solar_panel" onBlur={handleBlur} checked={_.get(values, 'ext_solar_panel') === 'Yes'} />
                    <label htmlFor="male">Yes</label>
                    <input type="radio" defaultValue="No" className={`${_.get(errors, 'ext_solar_panel') ? 'is-invalid' : ''}`} onChange={handleChange} name="ext_solar_panel" onBlur={handleBlur} checked={_.get(values, 'ext_solar_panel') === 'No'} />
                    <label htmlFor="female">No</label>
                    <div className="invalid-feedback">
                        {_.get(errors, 'ext_solar_panel')}
                    </div>
                </div>
                {/*login form*/}
                {/* <form class="login-signup-form"> */}
                <div className="form-group">
                    <label className="pb-1">Address Line1</label>
                    <input type="text" className={`form-control ${_.get(errors, 'addrs_one') ? 'is-invalid' : ''}`} value={values.addrs_one} placeholder="Enter Address Line1" onChange={handleChange} name="addrs_one" onBlur={handleBlur} />
                    <div className="invalid-feedback">
                        {_.get(errors, 'addrs_one')}
                    </div>
                </div>
                {/* Password */}
                {/* <div className="form-group">
                    <div className="row">
                        <div className="col">
                            <label className="pb-1">Address Line2</label>
                        </div>
                    </div>
                    <input type="text" className={`form-control ${_.get(errors, 'addrs_two') ? 'is-invalid' : ''}`} value={values.addrs_two} placeholder="Enter Address Line2" onChange={handleChange} name="addrs_two" onBlur={handleBlur} />
                    <div className="invalid-feedback">
                        {_.get(errors, 'addrs_two')}
                    </div>
                </div> */}
                {/* Phone */}
                <div className="form-group">
                    <div className="row">
                        <div className="col">
                            <label className="pb-1">City</label>
                        </div>
                    </div>
                    <input type="text" className={`form-control ${_.get(errors, 'city') ? 'is-invalid' : ''}`} value={values.city} placeholder="Enter City" onChange={handleChange} name="city" onBlur={handleBlur} />
                    <div className="invalid-feedback">
                        {_.get(errors, 'city')}
                    </div>
                </div>
                {/* Password */}
                <div className="form-group">
                    <div className="row">
                        <div className="col">
                            <label className="pb-1">Zipcode</label>
                        </div>
                    </div>
                    <input type="text" className={`form-control ${_.get(errors, 'zipcode') ? 'is-invalid' : ''}`} value={values.zipcode} placeholder="Enter Zipcode" onChange={handleChange} name="zipcode" onBlur={handleBlur} />
                    <div className="invalid-feedback">
                        {_.get(errors, 'zipcode')}
                    </div>
                </div>
                <div className="form-group row">
                    {/* Submit */}
                    <button type="button" disabled={isRequesting ? true : false} onClick={() => this.setState({ currentStep: 0 })} className="col-sm btn solid-btn border-radius mt-2 mb-3 mr-3">Back</button>
                    <button className="col-sm btn solid-btn border-radius mt-2 mb-3 ml-3">{isRequesting ? <i className="fas fa-spinner fa-spin fa-lg"></i> : 'Submit'}</button>
                </div>
            </div>
        )
    }

    renderStepView = (handleChange, handleBlur, values, errors) => {
        let { currentStep } = this.state;
        if (currentStep === 0) {
            return this.stepOne(handleChange, handleBlur, values, errors);
        } else if (currentStep === 1) {
            return this.stepTwo(handleChange, handleBlur, values, errors);
        }
    }

    static getDerivedStateFromProps(nextProps, state) {
        if (state.type !== nextProps.type) {
            if (nextProps.type === ActionTypes.POST_SIGNUP_PENDING) {
                return {
                    isRequesting: nextProps.isRequesting,
                    type: nextProps.type,
                    redirect: false
                }
            } else if (nextProps.type === ActionTypes.POST_SIGNUP_SUCCESS) {
                return {
                    isRequesting: nextProps.isRequesting,
                    message: nextProps.message,
                    type: nextProps.type, userData: nextProps.userData, redirect: true
                }
            } else if (nextProps.type === ActionTypes.POST_SIGNUP_FAILURE) {
                return {
                    isRequesting: nextProps.isRequesting,
                    message: nextProps.message,
                    type: nextProps.type, userData: nextProps.userData, redirect: false
                }
            }
        }
        return null;
    }

    handleRedirectPage = () => {
        let { reqType, redirect } = this.state;
        if (redirect && reqType !== 'popup') {
            this.props.history.push('/register/docusign');
        } else {

        }
    }

    componentDidUpdate(prevProps) {
        if (this.props.type === ActionTypes.POST_SIGNUP_SUCCESS && prevProps.type !== this.props.type) {
            this.handleRedirectPage();
        }
    }


    render() {
        let { message, reqType, redirect } = this.state;
        const emailTest = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/i;
        return (
            <div>
                <div>
                    {/*body content wrap start*/}
                    <div className="main">
                        {/*hero section start*/}
                        <section className="hero-section ptb-100 gradient-overlay full-screen" style={{ background: 'url("assets/images/project-details.jpg")no-repeat center center / cover' }}>
                            <div className="container">
                                <div className="row align-items-center justify-content-between pt-5 pt-sm-5 pt-md-5 pt-lg-0">
                                    <div className="col-md-7 col-lg-6">

                                        <div className="hero-content-left text-white">
                                            <a className="navbar-brand" href="#">
                                                <img src="assets/images/logo-white.png" width={160} alt="logo" className="img-fluid" />
                                            </a>
                                            <h1 className="text-white">PERSONAL DETAILS</h1>
                                            <p className="lead">Tell us something more about you</p>
                                        </div>
                                    </div>
                                    <div className="col-md-5 col-lg-5">
                                        <div className="card login-signup-card shadow-lg mb-0">

                                            <Formik
                                                innerRef={this.formRef}
                                                initialValues={{
                                                    full_name: "",
                                                    email: "",
                                                    phone: "",
                                                    home_owner: "",
                                                    electric_vehicle: "",
                                                    ext_solar_panel: "",
                                                    addrs_one: "",
                                                    // addrs_two: "",
                                                    city: "",
                                                    zipcode: "",
                                                    passwd: "",
                                                }}
                                                validate={values => {
                                                    let errors = {};
                                                    if (values.full_name === "") {
                                                        errors.full_name = "FullName is required";
                                                    } else if (!/^[a-zA-Z][a-zA-Z ]*$/.test(values.full_name)) {
                                                        errors.full_name = "Name should only contain Alphabets";
                                                    }
                                                    if (values.phone === "") {
                                                        errors.phone = "Phone is required";
                                                    } else if (!/^()[0-9]*$/.test(values.phone)) {
                                                        errors.phone = "Invalid Phone# format";
                                                    }
                                                    if (values.email === "") {
                                                        errors.email = "Email is required";
                                                    } else if (!emailTest.test(values.email)) {
                                                        errors.email = "Invalid email address format";
                                                    }
                                                    if (values.passwd !== values.repeat_passwd) {
                                                        errors.repeat_passwd = "Password's did not match";
                                                    }
                                                    if (values.passwd === "") {
                                                        errors.passwd = "Password is required";
                                                    } else if (_.size(values.passwd) < 8) {
                                                        errors.passwd = "Password Should be Min. 8 Chars"
                                                    }
                                                    if (values.home_owner === "") {
                                                        errors.home_owner = "Please select any option"
                                                    }
                                                    if (values.ext_solar_panel === "") {
                                                        errors.ext_solar_panel = "Please select any option"
                                                    }
                                                    if (values.electric_vehicle === "") {
                                                        errors.electric_vehicle = "Please select any option"
                                                    }
                                                    if (values.addrs_one === "") {
                                                        errors.addrs_one = "FullName is required"
                                                    }
                                                    // if (values.addrs_two === "") {
                                                    //     errors.addrs_two = "FullName is required"
                                                    // }
                                                    if (values.city === "") {
                                                        errors.city = "FullName is required"
                                                    } else if (!/^[a-zA-Z][a-zA-Z ]*$/.test(values.city)) {
                                                        errors.city = "City Name should only contain Alphabets";
                                                    }
                                                    if (values.zipcode === "") {
                                                        errors.zipcode = "FullName is required  "
                                                    } else if (!/^[0-9]*$/.test(values.zipcode) || _.size(values.zipcode) !== 5) {
                                                        errors.zipcode = "Invalid Zipcode   # format";
                                                    }
                                                    return errors;
                                                }}
                                                onSubmit={(values) => {
                                                    if (values.full_name && values.email && values.phone && values.home_owner && values.electric_vehicle && values.ext_solar_panel && values.addrs_one && values.city && values.zipcode && values.passwd) {
                                                        const { full_name, email, phone, passwd, home_owner, electric_vehicle, ext_solar_panel, addrs_one,  city, zipcode } = values;
                                                        if (home_owner === 'No' && ext_solar_panel === 'Yes') {
                                                            this.setState({ reqType: 'popup' })
                                                        }
                                                        this.props.signUp({ full_name, email, phone, passwd, home_owner, electric_vehicle, ext_solar_panel, addrs_one,  city, zipcode });
                                                    }
                                                }}
                                            >
                                                {({ values,
                                                    errors,
                                                    touched,
                                                    handleChange,
                                                    handleBlur,
                                                    handleSubmit,
                                                }) => (<>
                                                    {message && <div className="alert alert-warning">
                                                        <p>{message}</p>
                                                    </div>}
                                                    <Form className="login-signup-form">
                                                        {this.renderStepView(handleChange, handleBlur, values, errors)}
                                                    </Form>
                                                </>
                                                    )}
                                            </Formik>
                                        </div>
                                    </div>
                                    <div className="shape-bottom">
                                        <img src="assets/images/hero-shape-bottom.svg" alt="shape" className="bottom-shape img-fluid" />
                                    </div>
                                </div></div></section>
                        {/*hero section end*/}
                    </div>
                    {/*body content wrap end*/}
                </div>
                {redirect && reqType === 'popup' && <SweetAlert
                    success
                    showCancel={false}
                    confirmBtnText="Ok"
                    confirmBtnBsStyle="success"
                    title="Thank you for showing interest!"
                    onConfirm={() => this.props.history.push('/')}
                    focusConfirmBtn
                >we will get back to you shortly.</SweetAlert>}
            </div>
        );
    }
};

function mapStateToProps(state) {
    return {
        isRequesting: state.AuthReducer.isRequesting,
        type: state.AuthReducer.type,
        userData: state.AuthReducer.userData,
        message: state.AuthReducer.message
    }
}
function mapDispatchToProps(dispatch) {
    return bindActionCreators(ActionCreators, dispatch);
}


export default connect(mapStateToProps, mapDispatchToProps)(Register);