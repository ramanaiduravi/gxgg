import React from 'react';
import Preloader from '../../Components/Preloader';
import SideVerticalNav from '../../Components/SideVerticalNav';
import TopHeader from '../../Components/TopHeader';
import Chart from "react-google-charts";
import { connect } from 'react-redux';
import { ActionCreators } from '../../Actions';
import { bindActionCreators } from 'redux';
import * as ActionTypes from '../../Actions/ActionTypes';
import ReactEcharts from 'echarts-for-react';

class AIImpact extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            redirect: false
        }
    }

    static getDerivedStateFromProps(nextProps, state) {
        if (nextProps.authType === ActionTypes.SIGNOUT_SUCCESS) {
            return {
                redirect: true
            }
        }
        return null;
    }

    handleRouteToLogin = () => {
        if (this.state.redirect) {
            return this.props.history.push('/');
        }
    }

    getResidentialChart = () => {
        return {
            responsive: true,
            maintainAspectRatio: false,
            height: '300px',
            color: ['#3398DB'],
            tooltip: {
                trigger: 'axis',
                axisPointer: {            
                    type: 'shadow'        
                }
            },
            legend: {
                orient: 'horizontal',
                left: 'right',
                data: ['Electric', 'Solar']
            },
            grid: {
                top: '10%',
                left: '5%',
                right: '8%',
                bottom: '10%',
                containLabel: true
            },
            xAxis: [
                {
                    type: 'category',
                    name: "Month",
                    nameLocation: 'middle',
                    nameGap: 30,
                    data: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sept', 'Oct', 'Nov', 'Dec'],
                    axisTick: {
                        alignWithLabel: true
                    }
                }
            ],
            yAxis: [
                {
                    name: 'Household Numbers',
                    type: 'value',
                    nameLocation: 'middle',
                    nameGap: 30, gridIndex: 0,
                }
            ],
            series: [
                {
                    name: 'Household Numbers',
                    type: 'bar',
                    barWidth: '60%',
                    data: [10, 52, 200, 334, 390, 330, 220, 200, 334, 390, 200, 334],
                    itemStyle: {
                        color: '#2e3192'
                    }
                }
            ]
        };
    }

    render() {
        return (
            <div>
                {this.handleRouteToLogin()}
                <div>
                    {/*loader start*/}
                    {/* <Preloader /> */}
                    {/*loader end*/}
                    <div className="container-fluid">
                        {/* Begin page */}
                        <div id="layout-wrapper">
                            <TopHeader onSignOut={() => this.props.signOut()} />
                            <SideVerticalNav />
                            {/* Left Sidebar End */}
                            {/* ============================================================== */}
                            {/* Start right Content here */}
                            {/* ============================================================== */}
                            <div className="main-content">
                                <div className="page-content">
                                    {/* start page title */}
                                    <div className="row">
                                        <div className="col-12">
                                            <div className="page-title-box d-flex align-items-center justify-content-between">
                                                <h4 className="page-title mb-0 font-size-18">Intelligent Energy Savings For You</h4>
                                                <div className="page-title-right">
                                                    <ol className="breadcrumb m-0">
                                                        <li className="breadcrumb-item"><a href="javascript: void(0);">Powered by our
                        cutting edge AI engine, running on GXG AI platform</a></li>
                                                    </ol>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    {/* end page title */}
                                    <div className="row">
                                        <div className="col-4">
                                            <div className="card">
                                                <div className="card-body">
                                                    <div className="row justify-content-between">
                                                        <div className="col-2"><img width={18} src="assets/images/team.png" /></div>
                                                        <div className="col-8 cus-col-8"><h4 style={{ color: '#2e3192' }}> <strong> 705</strong></h4></div>
                                                    </div>
                                                    <h6 className="mt-2">Households On-board</h6>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="col-4">
                                            <div className="card">
                                                <div className="card-body">
                                                    <div className="row justify-content-between">
                                                        <div className="col-2"><img width={18} src="assets/images/battery.png" /></div>
                                                        <div className="col-8 cus-col-8"><h4 style={{ color: '#2e3192' }}> <strong> 5,735,745</strong></h4></div>
                                                    </div>
                                                    <h6 className="mt-2">Solar Deposited [KWh]</h6>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="col-4">
                                            <div className="card">
                                                <div className="card-body">
                                                    <div className="row justify-content-between">
                                                        <div className="col-2"><img width={18} src="assets/images/pine.png" /></div>
                                                        <div className="col-8 cus-col-8"><h4 style={{ color: '#2e3192' }}> <strong> 5,682</strong></h4></div>
                                                    </div>
                                                    <h6 className="mt-2">Trees Saved [Acres]</h6>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="col-4">
                                            <div className="card">
                                                <div className="card-body">
                                                    <div className="row justify-content-between">
                                                        <div className="col-2"><img width={18} src="assets/images/cloud.png" /></div>
                                                        <div className="col-8 cus-col-8"><h4 style={{ color: '#2e3192' }}> <strong> 4,828</strong></h4></div>
                                                    </div>
                                                    <h6 className="mt-1">Reduced CO2 Emission [Mt]</h6>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="col-4">
                                            <div className="card">
                                                <div className="card-body">
                                                    <div className="row justify-content-between">
                                                        <div className="col-2"><img width={18} src="assets/images/dollar.png" /></div>
                                                        <div className="col-8 cus-col-8"><h4 style={{ color: '#2e3192' }}> <strong> 229,429</strong></h4></div>
                                                    </div>
                                                    <h6 className="mt-2">Community Savings [USD]</h6>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="col-4">
                                            <div className="card">
                                                <div className="card-body">
                                                    <div className="row justify-content-between">
                                                        <div className="col-2"><img width={18} src="assets/images/leaf.png" /></div>
                                                        <div className="col-8"><h4 style={{ color: '#2e3192' }}> <strong> 2,844,929</strong></h4></div>
                                                    </div>
                                                    <h6 className="mt-2">Environmental Impact [USD]</h6>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div className="row">
                                        <div className="col-sm">

                                            <div className="card">
                                                <div className="card-body">
                                                    <h5>Residential Household On-board</h5>
                                                    <ReactEcharts option={this.getResidentialChart()} style={{ height: '400px' }} />
                                                </div>
                                            </div>
                                        </div>
                                        <div className="col-sm">

                                            <div className="card">
                                                <div className="card-body">
                                                    <h5>Solar Deposit</h5>
                                                    <Chart
                                                        height={'400px'}
                                                        chartType="AreaChart"
                                                        loader={<div>Loading Chart</div>}
                                                        data={[
                                                            ['Month', 'Energy [KWh]'],
                                                            ['Jan', 140],
                                                            ['Feb', 140],
                                                            ['Mar', 660],
                                                            ['Apr', 1030],
                                                            ['May', 1030],
                                                            ['Jun', 1030],
                                                            ['Jul', 1030],
                                                            ['Aug', 830],
                                                            ['Sep', 630],
                                                            ['Oct', 1030],
                                                            ['Nov', 1030],
                                                            ['Dec', 1030],
                                                        ]}
                                                        options={{
                                                            // title: 'Solar Production',
                                                            hAxis: { title: 'Month', titleTextStyle: { color: '#333' }},
                                                            vAxis: { title: 'Energy [KWh]', minValue: 0 },
                                                            // For the legend to fit, we make the chart area smaller
                                                            chartArea: { height: '70%', width:'90%' },
                                                            // lineWidth: 25
                                                            legend: 'none'
                                                        }}
                                                    />
                                                </div>
                                            </div>
                                        </div>
                                        <div className="col-sm">

                                            <div className="card">
                                                <div className="card-body">
                                                    <h5>Trees Saved</h5>
                                                    <Chart
                                                        height={'400px'}
                                                        chartType="AreaChart"
                                                        loader={<div>Loading Chart</div>}
                                                        data={[
                                                            ['Month', 'Acres'],
                                                            ['Jan', 140],
                                                            ['Feb', 140],
                                                            ['Mar', 660],
                                                            ['Apr', 1030],
                                                            ['May', 1030],
                                                            ['Jun', 1030],
                                                            ['Jul', 1030],
                                                            ['Aug', 830],
                                                            ['Sep', 630],
                                                            ['Oct', 1030],
                                                            ['Nov', 1030],
                                                            ['Dec', 1030],
                                                        ]}
                                                        options={{
                                                            // title: 'Tree\'s Saved',
                                                            hAxis: { title: 'Monthly', titleTextStyle: { color: '#333' } },
                                                            vAxis: { title: 'Acres', minValue: 0 },
                                                            colors: ['#CCC'],
                                                            // For the legend to fit, we make the chart area smaller
                                                            chartArea: { height: '70%', width:'90%' },
                                                            // lineWidth: 25
                                                            legend: 'none'
                                                        }}
                                                        // For tests
                                                        rootProps={{ 'data-testid': '1' }}
                                                    />
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="row">
                                        <div className="col-sm">

                                            <div className="card">
                                                <div className="card-body">
                                                    <h5>CO2 Emission Reduction</h5>
                                                    <Chart
                                                        height={'400px'}
                                                        chartType="AreaChart"
                                                        loader={<div>Loading Chart</div>}
                                                        data={[
                                                            ['Month', 'Emission [Mt]'],
                                                            ['Jan', 140],
                                                            ['Feb', 140],
                                                            ['Mar', 660],
                                                            ['Apr', 1030],
                                                            ['May', 1030],
                                                            ['Jun', 1030],
                                                            ['Jul', 1030],
                                                            ['Aug', 830],
                                                            ['Sep', 630],
                                                            ['Oct', 1030],
                                                            ['Nov', 1030],
                                                            ['Dec', 1030]
                                                        ]}
                                                        options={{
                                                            // title: 'Company Performance',
                                                            hAxis: { title: 'Month', titleTextStyle: { color: '#333' } },
                                                            vAxis: { title: 'Emission [Mt]', minValue: 0 },
                                                            colors: ['#CC2323'],
                                                            // For the legend to fit, we make the chart area smaller
                                                            chartArea: { height: '70%', width:'90%' },
                                                            // lineWidth: 25
                                                            legend: 'none'
                                                        }}
                                                        // For tests
                                                        rootProps={{ 'data-testid': '1' }}
                                                    />
                                                </div>
                                            </div>
                                        </div>
                                        <div className="col-sm">
                                            <div className="card">
                                                <div className="card-body">
                                                    <h5>Environmental Impact</h5>
                                                    <Chart
                                                        height={'400px'}
                                                        chartType="AreaChart"
                                                        loader={<div>Loading Chart</div>}
                                                        data={[
                                                            ['Month', 'Environmental Impact in $'],
                                                            ['Jan', 140],
                                                            ['Feb', 140],
                                                            ['Mar', 660],
                                                            ['Apr', 1030],
                                                            ['May', 1030],
                                                            ['Jun', 1030],
                                                            ['Jul', 1030],
                                                            ['Aug', 830],
                                                            ['Sep', 630],
                                                            ['Oct', 1030],
                                                            ['Nov', 1030],
                                                            ['Dec', 1030]
                                                        ]}
                                                        options={{
                                                            // title: 'Environmental Impact',
                                                            hAxis: { title: 'Month', titleTextStyle: { color: '#333' } },
                                                            vAxis: { title: 'Environmental Impact in $', minValue: 0 },
                                                            colors: ['pink'],
                                                            // For the legend to fit, we make the chart area smaller
                                                            chartArea: { height: '70%', width:'90%' },
                                                            // lineWidth: 25
                                                            legend: 'none'
                                                        }}
                                                        // For tests
                                                        rootProps={{ 'data-testid': '1' }}
                                                    />
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    {/* <h4 style={{ color: '#2e3192' }}>Your Community's Environmental Impact</h4>
                                    <div className="row">
                                        <div className="col-sm">

                                            <div className="card">
                                                <div className="card-body">
                                                    <h5 style={{ color: '#000' }}>GXG Communities</h5>
                                                    <p style={{ color: '#CCC' }}>Green Efficiency</p>
                                                    <Chart
                                                        height={'400px'}
                                                        chartType="Scatter"
                                                        loader={<div>Loading Chart</div>}
                                                        data={[
                                                            ['Hours Studied', 'Final'],
                                                            [0, 67],
                                                            [1, 88],
                                                            [2, 77],
                                                            [3, 93],
                                                            [4, 85],
                                                            [5, 91],
                                                            [6, 71],
                                                            [7, 78],
                                                            [8, 93],
                                                            [9, 80],
                                                            [10, 82],
                                                            [0, 75],
                                                            [5, 80],
                                                            [3, 90],
                                                            [1, 72],
                                                            [5, 75],
                                                            [6, 68],
                                                            [7, 98],
                                                            [3, 82],
                                                            [9, 94],
                                                            [2, 79],
                                                            [2, 95],
                                                            [2, 86],
                                                            [3, 67],
                                                            [4, 60],
                                                            [2, 80],
                                                            [6, 92],
                                                            [2, 81],
                                                            [8, 79],
                                                            [9, 83],
                                                            [3, 75],
                                                            [1, 80],
                                                            [3, 71],
                                                            [3, 89],
                                                            [4, 92],
                                                            [5, 85],
                                                            [6, 92],
                                                            [7, 78],
                                                            [6, 95],
                                                            [3, 81],
                                                            [0, 64],
                                                            [4, 85],
                                                            [2, 83],
                                                            [3, 96],
                                                            [4, 77],
                                                            [5, 89],
                                                            [4, 89],
                                                            [7, 84],
                                                            [4, 92],
                                                            [9, 98],
                                                        ]}
                                                        options={{
                                                            // Material design options
                                                            // chart: {
                                                            //     title: "GXG Communitie's",
                                                            //     subtitle: 'Green Efficiency',
                                                            // },
                                                            hAxis: { title: 'Solar/Grid Ratio' },
                                                            vAxis: { title: 'Green Efficiency (%)' },
                                                            colors: ['#2e3192', '#5f5f5f']
                                                        }}
                                                    />
                                                </div>

                                            </div>
                                        </div>
                                        <div className="col-sm">

                                            <div className="card">
                                                <div className="card-body">
                                                    <h5>Your Community's Relative Contribution</h5>
                                                    <p style={{ color: '#FFF' }}>....s</p>
                                                    <Chart
                                                        height={'400px'}
                                                        chartType="PieChart"
                                                        loader={<div>Loading Chart</div>}
                                                        data={[
                                                            ['Task', 'Hours per Day'],
                                                            ['Savings', 11],
                                                            ['Saving Trees', 2],
                                                            ['Reducing Carbon Emission', 2],
                                                            ['Solar Production', 2],
                                                        ]}
                                                        options={{
                                                            // title: 'Your Communitie\'s Relative Contribution',
                                                            // Just add this option
                                                            pieHole: 0.5,
                                                            colors: ['#2e3192', '#CC2323', '#6d0000', '5f5f5f']
                                                        }}
                                                        rootProps={{ 'data-testid': '3' }}
                                                    />
                                                </div>

                                            </div>
                                        </div>
                                    </div> */}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div >
        );
    }
};

function mapStateToProps(state) {
    return {
        authType: state.AuthReducer.type
    }
}

function mapDispatchToProps(dispatch) {
    return bindActionCreators(ActionCreators, dispatch);
}

export default connect(mapStateToProps, mapDispatchToProps)(AIImpact);