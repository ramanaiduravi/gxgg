import React from 'react';
import { Link } from 'react-router-dom';
import Preloader from '../../Components/Preloader';
import SideVerticalNav from '../../Components/SideVerticalNav';
import TopHeader from '../../Components/TopHeader';
import { connect } from 'react-redux';
import { ActionCreators } from '../../Actions';
import { bindActionCreators } from 'redux';
import * as ActionTypes from '../../Actions/ActionTypes';
import _ from 'lodash';


class Profile extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            userData: {}, loader: false, redirect: false,
            type: undefined, dashboardData: {}, errorMessage: ''
        }
    }
    componentDidMount() {
        // this.props.getEnergyScannerData();
        this.handlePropsData();
        this.handleFetchData();
    }

    static getDerivedStateFromProps(nextProps, state) {
        if (state.type !== nextProps.type) {
            if (nextProps.type === ActionTypes.GET_ENERGYSCANNERDATA_PENDING) {
                return {
                    loader: nextProps.isRequesting,
                    type: nextProps.type
                }
            } else if (nextProps.type === ActionTypes.GET_ENERGYSCANNERDATA_SUCCESS) {
                return {
                    loader: nextProps.isRequesting,
                    type: nextProps.type,
                    dashboardData: nextProps.dashboardData,
                }
            } else if (nextProps.type === ActionTypes.GET_ENERGYSCANNERDATA_FAILURE) {
                return {
                    loader: nextProps.isRequesting,
                    type: nextProps.type,
                    errorMessage: nextProps.errorMessage,
                    dashboardData: {}
                }
            }
        } else if (nextProps.authType === ActionTypes.SIGNOUT_SUCCESS) {
            return {
                redirect: true
            }
        }
        return null;
    }

    handlePropsData = () => {
        let userData = localStorage.getItem('userData');
        this.setState({ userData: JSON.parse(userData) }, () => this.setState({ loader: false }));
    }

    handleFetchData = () => {
        this.props.getEnergyScannerData(this.state.month);
    }

    handleRouteToLogin = () => {
        if (this.state.redirect) {
            return this.props.history.push('/');
        }
    }

    render() {
        let { dashboardData, userData, loader } = this.state;
        console.log(!!_.get(userData, 'documents') , _.get(userData, 'documents', []), userData);
        return (
            <div>
                {this.handleRouteToLogin()}
                {loader && <Preloader />}
                {/*loader end*/}
                <div className="container-fluid">
                    {/* Begin page */}
                    <div id="layout-wrapper">
                        <TopHeader onSignOut={() => this.props.signOut()} />
                        <SideVerticalNav />
                        {/* Left Sidebar End */}
                        {/* ============================================================== */}
                        {/* Start right Content here */}
                        {/* ============================================================== */}
                        <div className="main-content">
                            <div className="page-content">
                                {/* start page title */}
                                <div className="row">
                                    <div className="col-12">
                                        <div className="page-title-box d-flex align-items-center justify-content-between">
                                            <h4 className="page-title mb-0 font-size-18">Profile</h4>
                                            <div className="page-title-right">
                                                <ol className="breadcrumb m-0">
                                                    <li className="breadcrumb-item"><Link to={'/'}>Home</Link></li>
                                                    <li className="breadcrumb-item active">Profile</li>
                                                </ol>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                {/* end page title */}
                                {/* start row */}
                                <div className="row">
                                    <div className="col-md-12 col-xl-3">
                                        <div className="card">
                                            <div className="card-body">
                                                <div className="profile-widgets py-3">
                                                    <div className="text-center">
                                                        <div className>
                                                            <img src="assets/images/users/avatar-2.jpg" alt="" className="avatar-lg mx-auto img-thumbnail rounded-circle" />
                                                            <div className="online-circle"><i className="fas fa-circle text-success" />
                                                            </div>
                                                        </div>
                                                        <div className="mt-3 ">
                                                            <a href="#" className="text-dark font-weight-medium font-size-16">{_.get(userData, 'full_name', '')}</a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="card">
                                            <div className="card-body">
                                                <h5 className="card-title mb-3">Personal Information</h5>
                                                <div className="mt-3">
                                                    <p className="font-size-12 text-muted mb-1">Email Address</p>
                                                    <h6 className>{_.get(userData, 'email', '')}</h6>
                                                </div>
                                                <div className="mt-3">
                                                    <p className="font-size-12 text-muted mb-1">Phone number</p>
                                                    <h6 className>{_.get(userData, 'phone', '')}</h6>
                                                </div>
                                                <div className="mt-3">
                                                    <p className="font-size-12 text-muted mb-1">Address -1</p>
                                                    <h6 className>{_.get(userData, 'addrs_one', '')}</h6>
                                                </div>
                                                <div className="mt-3">
                                                    <p className="font-size-12 text-muted mb-1">Address -2</p>
                                                    <h6 className>{_.get(userData, 'addrs_two', '')}</h6>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="col-md-12 col-xl-9">
                                        <div className="row">
                                            <div className="col-md-3">
                                                <div className="card">
                                                    <div className="card-body">
                                                        <p className="mb-2" style={{ whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}><i className="bx bx-dollar font-size-24 align-middle mr-1" style={{ color: '#001148' }} /> Total Bill</p>
                                                        <h4 className="mb-0" style={{ color: '#2e3192' }}>${_.get(dashboardData, 'usage_efficiency_percentage.Current Bill', '')}</h4>
                                                        {/* <span className="badge badge-soft-info mr-2">6.5% less than Apr bill<i className="mdi mdi-arrow-up ml-1" />
                                                    </span> */}
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="col-md-3">
                                                <div className="card">
                                                    <div className="card-body">
                                                        <p className="mb-2" style={{ whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}><i className="bx bx-dollar font-size-24 align-middle mr-1" style={{ color: '#001148' }} />Electric Power</p>
                                                        <h4 className="mb-0" style={{ color: '#2e3192' }}>${_.get(dashboardData, 'usage_efficiency_percentage.Electric Bill', '')}</h4>
                                                        <div style={{ color: '#6542C7' }}>
                                                            {/* <span className="badge badge-soft-primary mr-2">19.8% less than Apr usage<i className="mdi mdi-arrow-down ml-1" />
                                                        </span> */}
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="col-md-3">
                                                <div className="card">
                                                    <div className="card-body">
                                                        <p className="mb-2" style={{ whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}><i className="bx bx-dollar font-size-24 align-middle mr-1" style={{ color: '#001148' }} />Solar Power</p>
                                                        <h4 className="mb-0" style={{ color: '#2e3192' }}>${_.get(dashboardData, 'usage_efficiency_percentage.Solar Power', '')}</h4>
                                                        {/* <span className="badge badge-soft-warning mr-2">6.9% more than Apr usage<i className="mdi mdi-arrow-up ml-1" />
                                                    </span> */}
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="col-md-3">
                                                <div className="card">
                                                    <div className="card-body">
                                                        <p className="mb-2" style={{ whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}><i className="bx bx-dollar font-size-24 align-middle mr-1" style={{ color: '#001148' }} /> Your Savings</p>
                                                        <h4 className="mb-0" style={{ color: '#2e3192' }}>${_.get(dashboardData, 'usage_efficiency_percentage.Your Savings', '')}</h4>
                                                        {/* <span className="badge badge-soft-info mr-2">6.5% less than Apr bill<i className="mdi mdi-arrow-up ml-1" />
                                                    </span> */}
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <br />
                                        <div className="row">
                                            <div className="col-xl-4">
                                                <div className="card">
                                                    <div className="card-body">
                                                        <div className="row">
                                                            <div className="col-12">
                                                            <p style={{ whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}><i className="dripicons-battery-full font-size-20 align-middle mr-1" style={{ color: '#001148' }} />Solar Power Deposited [KWh]</p>
                                                            </div>
                                                            <div className="row col-md-12">
                                                                <div className="col-7">
                                                                    <p style={{ fontWeight: 'bold', color: '#2e3192', fontSize: '15.5px', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{_.get(dashboardData, 'solar_energy_usage_insights.Solar Power Produced', '')}</p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div className="card">
                                                    <div className="card-body">
                                                        <div className="row">
                                                            <div className="col-12">
                                                            <p style={{ whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}><i className="dripicons-battery-full font-size-20 align-middle mr-1" style={{ color: '#001148' }} />Solar Power Withdrawn [KWh]</p>
                                                            </div>
                                                            <div className="row col-md-12">
                                                                <div className="col-7">
                                                                    <p style={{ fontWeight: 'bold', color: '#2e3192', fontSize: '15.5px', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{_.get(dashboardData, 'solar_energy_usage_insights.Solar Power Consumed', '')}</p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div className="card">
                                                    <div className="card-body">
                                                        <div className="row">
                                                            <div className="col-12">
                                                            <p style={{ whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}><i className="fas fa-leaf font-size-20 align-middle mr-1" style={{ color: '#42C782', }} />Green Efficiency</p>
                                                            </div>
                                                            <div className="row col-md-12">
                                                                <div className="col-5">
                                                                    <p style={{ fontWeight: 'bold', color: '#2e3192', fontSize: '15.5px', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{_.get(dashboardData, 'solar_energy_usage_insights.Solar Efficiency', '')} %</p>
                                                                </div>
                                                                <div className="col-7">
                                                                    <div style={{ color: '#61D097' }}>
                                                                        <p style={{ fontSize: '12px', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}><i className="bx bxs-like ml-1" />Nothing to worry about</p>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="col-xl-4">
                                                <div className="card">
                                                    <div className="card-body">
                                                        <div className="row">
                                                            <div className="col-12" style={{ margin: 5 }}>
                                                                <p style={{ whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}><i className="fas fa-dollar-sign font-size-20 align-middle mr-1" style={{ color: '#429BC7' }} />Solar Deposit Rate / AC [KWh]</p>
                                                            </div>
                                                            <div className="row col-md-12">
                                                                <div className="col-7">
                                                                    <p style={{ fontWeight: 'bold', color: '#2e3192', fontSize: '15.5px', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>${_.get(dashboardData, 'solar_energy_usage_insights.Solar Purchase Price', '')}</p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div className="card">
                                                    <div className="card-body">
                                                        <div className="row">
                                                            <div className="col-12">
                                                                <p className="mb-2"><img style={{ width: 20, height: 20 }} src="assets/images/GXG.png" />GXG Debits [KWh]</p>
                                                            </div>
                                                            <div className="row col-md-12">
                                                                <div className="col-7">
                                                                    <p style={{ fontWeight: 'bold', color: '#2e3192', fontSize: '15.5px', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{_.get(dashboardData, 'solar_energy_usage_insights.GXG-Debits', '')}</p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div className="card">
                                                    <div className="card-body">
                                                        <div className="row">
                                                            <div className="col-12">
                                                                <p className="mb-2"><img style={{ width: 20, height: 20 }} src="assets/images/GXG.png" />GXG Credits [KWh]</p>
                                                            </div>
                                                            <div className="row col-md-12">
                                                                <div className="col-7">
                                                                    <p style={{ fontWeight: 'bold', color: '#2e3192', fontSize: '15.5px', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{_.get(dashboardData, 'solar_energy_usage_insights.GXG-Credits', '')}</p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            {/* {!!_.get(userData, 'documents') && _.get(userData, 'documents', []).map((document, index) => {
                                return (<div className="float-right" align='center' key={index}>
                                    <img src="assets/images/pdf.png" /><br></br>
                                    <a target="_blank" href={`http://ec2-54-151-76-120.us-west-1.compute.amazonaws.com/download_documents?subscriber_id=${_.get(userData, 'subscriber_id')}&document_name=${document}`}>{`${document}`}</a>
                                </div>)
                            })} */}
                        </div>
                        {/* END layout-wrapper */}
                    </div>
                    {/* end container-fluid */}
                </div>
            </div >

        );
    }
};

function mapStateToProps(state) {
    return {
        dashboardData: state.DashboardReducer.dashboardData,
        authType: state.AuthReducer.type,
        type: state.DashboardReducer.type,
        isRequesting: state.DashboardReducer.isRequesting,
        errorMessage: state.DashboardReducer.message,
    }
}

function mapDispatchToProps(dispatch) {
    return bindActionCreators(ActionCreators, dispatch);
}

export default connect(mapStateToProps, mapDispatchToProps)(Profile);