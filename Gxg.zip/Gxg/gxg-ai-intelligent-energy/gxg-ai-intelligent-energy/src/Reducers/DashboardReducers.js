import * as ActionTypes from '../Actions/ActionTypes';
function base(state = {}, action) {
    switch (action.type) {
        case ActionTypes.GET_ENERGYSCANNERDATA_PENDING:
            return {
                ...state,
                isRequesting: true,
                message: '',
                type: action.type
            }
        case ActionTypes.GET_ENERGYSCANNERDATA_SUCCESS:
            return {
                ...state,
                isRequesting: false,
                dashboardData: action.payload,
                message: '',
                type: action.type
            }
        case ActionTypes.GET_ENERGYSCANNERDATA_FAILURE:
            return {
                ...state,
                isRequesting: false,
                dashboardData: {},
                type: action.type,
                message: action.message
            }
        default:
            return state;
    }
}

export default base;