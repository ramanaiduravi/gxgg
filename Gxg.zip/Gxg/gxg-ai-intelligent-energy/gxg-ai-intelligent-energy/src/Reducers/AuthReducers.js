import * as ActionTypes from '../Actions/ActionTypes';

function base(state = {}, action) {
    switch (action.type) {
        case ActionTypes.POST_LOGIN_PENDING:
        case ActionTypes.POST_SIGNUP_PENDING:
        case ActionTypes.POST_DOCUSIGN_PENDING:
        case ActionTypes.PUT_DOCUSIGN_PENDING:
        case ActionTypes.POST_PAYMENT_REPORTING_PENDING:
            return {
                ...state,
                isRequesting: true,
                message: '',
                type: action.type
            }
        case ActionTypes.POST_LOGIN_SUCCESS:
        case ActionTypes.POST_SIGNUP_SUCCESS:
            return {
                ...state,
                isRequesting: false,
                userData: action.payload,
                message: '',
                type: action.type
            }
        case ActionTypes.POST_DOCUSIGN_SUCCESS:
            return {
                ...state,
                isRequesting: false,
                docData: action.payload,
                message: '',
                type: action.type
            }
        case ActionTypes.POST_LOGIN_FAILURE:
        case ActionTypes.POST_SIGNUP_FAILURE:
            return {
                ...state,
                isRequesting: false,
                userData: {},
                type: action.type,
                message: action.message
            }
        case ActionTypes.POST_DOCUSIGN_FAILURE:
            return {
                ...state,
                isRequesting: false,
                docData: {},
                type: action.type,
                message: action.message
            }
        case ActionTypes.SIGNOUT_SUCCESS:
            return {
                ...state,
                isRequesting: false,
                userData: {},
                type: action.type,
                message: ''
            }
        case ActionTypes.PUT_DOCUSIGN_SUCCESS:
        case ActionTypes.PUT_DOCUSIGN_FAILURE:
        case ActionTypes.POST_PAYMENT_REPORTING_FAILURE:
        case ActionTypes.POST_PAYMENT_REPORTING_SUCCESS:
            return {
                ...state,
                type: action.type,
                isRequesting: false,
                message: action.message
            }
        case ActionTypes.GET_CHECKOUTID_SUCCESS:
            return {
                ...state,
                type: action.type,
                isRequesting: false,
                checkoutData: action.payload
            }
        case ActionTypes.GET_CHECKOUTID_FAILURE:
            return {
                ...state,
                type: action.type,
                isRequesting: false,
                checkoutData: {},
                message: action.message
            }
        case ActionTypes.GET_CHECKOUTID_PENDING:
            return {
                ...state,
                type: action.type,
                isRequesting: true,
                checkoutData: {},
                message: ''
            }
        default:
            return state;
    }
}

export default base;