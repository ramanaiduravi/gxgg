import { combineReducers } from 'redux';
import AuthReducer from './AuthReducers';
import DashboardReducer from './DashboardReducers';


const reducers = combineReducers({
    AuthReducer, DashboardReducer
});

export default reducers;