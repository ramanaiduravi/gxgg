import React from 'react';
import { Link } from 'react-router-dom';

const SideVerticalNav = () => {
    return (
        <div className="vertical-menu">
            <div className="h-100">
                <div className="user-wid text-center py-4">
                    <div className="user-img">
                        <img src="assets/images/users/avatar-2.jpg" alt="" className="avatar-md mx-auto rounded-circle" />
                    </div>
                    <div className="mt-3">
                        <a href="#" className="text-dark font-weight-medium font-size-16">Patrick Becker</a>
                    </div>
                </div>
                {/*- Sidemenu */}
                <div id="sidebar-menu">
                    {/* Left Menu Start */}
                    <ul className="metismenu list-unstyled" id="side-menu">
                        <li>
                            <Link to="/dashboard" className=" waves-effect">
                                <i className="bx bx-bolt-circle font-size-20 align-middle mr-1" />
                                <span>Energy Scanner</span>
                            </Link>
                        </li>
                        <li>
                            <Link to="/ai-impact" className=" waves-effect">
                                <i className="bx bx-globe font-size-20 align-middle mr-1" />
                                <span>GXG-AI Impact</span>
                            </Link>
                        </li>
                        <li>
                            <Link to="/profile" className=" waves-effect">
                                <i className="bx bx-user font-size-24 align-middle mr-1" />
                                <span>Profile</span>
                            </Link>
                        </li>
                    </ul>
                </div>
                {/* Sidebar */}
            </div>
        </div>
    );
};

export default SideVerticalNav;