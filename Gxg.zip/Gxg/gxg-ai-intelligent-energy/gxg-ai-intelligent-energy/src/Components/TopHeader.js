import React from 'react';
import { Link, useHistory } from 'react-router-dom';
import asyncLocalStorage from '../Utils/asyncLocalStorage';


const TopHeader = (props) => {
    const [redirect, setRedirect] = React.useState(false);
    const history = useHistory();

    const handleLogout = () => {
        props.onSignOut();
    }

    return (
        <header id="page-topbar">
            <div className="navbar-header">
                <div className="container-fluid">
                    <div className="float-right">
                        <div className="dropdown d-inline-block d-lg-none ml-2">
                            <button type="button" className="btn header-item noti-icon waves-effect" id="page-header-search-dropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i className="mdi mdi-magnify" />
                            </button>
                            <div className="dropdown-menu dropdown-menu-lg dropdown-menu-right p-0" aria-labelledby="page-header-search-dropdown">
                                <form className="p-3">
                                    <div className="form-group m-0">
                                        <div className="input-group">
                                            <input type="text" className="form-control" placeholder="Search ..." aria-label="Recipient's username" />
                                            <div className="input-group-append">
                                                <button className="btn btn-primary" type="submit"><i className="mdi mdi-magnify" /></button>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                        <div className="dropdown d-inline-block">
                            <button type="button" className="btn header-item noti-icon waves-effect" id="page-header-notifications-dropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i className="mdi mdi-bell-outline" />
                                {/* <span className="badge badge-danger badge-pill">3</span> */}
                            </button>
                            <div className="dropdown-menu dropdown-menu-lg dropdown-menu-right p-0" aria-labelledby="page-header-notifications-dropdown">
                                <div className="p-3">
                                    <div className="row align-items-center">
                                        <div className="col">
                                            <h6 className="m-0"> Notifications </h6>
                                        </div>
                                        <div className="col-auto">
                                            <a href="#!" className="small"> View All</a>
                                        </div>
                                    </div>
                                </div>
                                <div data-simplebar style={{ maxHeight: '230px' }}>
                                    <a href="#" className="text-reset notification-item">
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div className="dropdown d-inline-block">
                            <button type="button" className="btn header-item waves-effect" id="page-header-user-dropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <img className="rounded-circle header-profile-user" src="assets/images/users/avatar-2.jpg" alt="Header Avatar" />
                            </button>
                            <div className="dropdown-menu dropdown-menu-right">
                                {/* item*/}
                                <Link className="dropdown-item" to="/profile"><i className="bx bx-user font-size-16 align-middle mr-1" /> Profile</Link>
                                <div className="dropdown-divider" />
                                <button className="dropdown-item text-danger" onClick={async () => { return await handleLogout() }}><i className="bx bx-power-off font-size-16 align-middle mr-1 text-danger" />Logout</button>
                            </div>
                        </div>
                    </div>
                    <div>
                        {/* LOGO */}
                        <div className="navbar-brand-box">
                            <Link to="/" className="logo logo-dark">
                                <span className="logo-sm">
                                    <img src="assets/images/logo-light.png" alt="" height={20} />
                                </span>
                                <span className="logo-lg">
                                    <img src="assets/images/logo-dark.png" alt="" height={17} />
                                </span>
                            </Link>
                            <Link to="/" className="logo logo-light">
                                <span className="logo-sm">
                                    <img src="assets/images/logo-light.png" alt="" height={45} />
                                </span>
                                <span className="logo-lg">
                                    <img src="assets/images/logo-light.png" alt="" height={19} />
                                </span>
                            </Link>
                        </div>
                        <button type="button" className="btn btn-sm px-3 font-size-16 header-item toggle-btn waves-effect" id="vertical-menu-btn">
                            <i className="fa fa-fw fa-bars" />
                        </button>
                    </div>
                </div>
            </div>
        </header>
    );
};

export default TopHeader;