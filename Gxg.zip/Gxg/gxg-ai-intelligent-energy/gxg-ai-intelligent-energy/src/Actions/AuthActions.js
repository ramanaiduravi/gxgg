import * as AuthServices from '../Services/AuthServices';
import * as ActionTypes from '../Actions/ActionTypes';
import _ from 'lodash';


export const signIn = (reqData) => {
    return ((dispatch, getState) => {
        dispatch({ type: ActionTypes.POST_LOGIN_PENDING });
        AuthServices.signIn(reqData)
            .then(response => {
                dispatch({ type: ActionTypes.POST_LOGIN_SUCCESS, payload: response.body });
            })
            .catch(err => dispatch({ type: ActionTypes.POST_LOGIN_FAILURE, message: 'Incorrect Credentials' }))
    });
}


export const signUp = (reqData) => {
    return ((dispatch, getState) => {
        dispatch({ type: ActionTypes.POST_SIGNUP_PENDING });
        AuthServices.signUp(reqData)
            .then(response => {
                dispatch({ type: ActionTypes.POST_SIGNUP_SUCCESS, payload: response.body, message: 'User SignUp Successfully' });
            })
            .catch(err => dispatch({ type: ActionTypes.POST_SIGNUP_FAILURE, message: _.get(err, 'body.message', 'User SignUp Failed') }))
    });
}

export const getStatus = (subscriber_id) => {
    return (async (dispatch, getState) => {
        dispatch({ type: ActionTypes.POST_DOCUSIGN_PENDING })
        await AuthServices.getStatus()
            .then(async response => {
                if (response.auth_type === 'jwt' && response.logged) {
                    await AuthServices.docuSign(subscriber_id)
                        .then(docResponse => {
                            dispatch({ type: ActionTypes.POST_DOCUSIGN_SUCCESS, payload: docResponse })
                        })
                        .catch(err => {
                            dispatch({ type: ActionTypes.POST_DOCUSIGN_FAILURE });
                        })
                } else {
                    await AuthServices.jwtAuth()
                        .then(async authReponse => {
                            await AuthServices.docuSign(subscriber_id)
                                .then(docResponse => {
                                    dispatch({ type: ActionTypes.POST_DOCUSIGN_SUCCESS, payload: docResponse })
                                })
                                .catch(err => {
                                    dispatch({ type: ActionTypes.POST_DOCUSIGN_FAILURE });
                                })
                        })
                        .catch(err => {
                            dispatch({ type: ActionTypes.POST_DOCUSIGN_FAILURE });
                        })
                }
            })
            .catch(err => {

            })
    })
}

export const docuSignSuccess = (reqData) => {
    return ((dispatch, getState) => {
        dispatch({ type: ActionTypes.PUT_DOCUSIGN_PENDING });
        console.log('ksks', reqData);
        AuthServices.docuSignSuccess(reqData)
            .then(response => {
                dispatch({ type: ActionTypes.PUT_DOCUSIGN_SUCCESS, message: _.get(response, 'message') });
            })
            .catch(err => dispatch({ type: ActionTypes.PUT_DOCUSIGN_FAILURE, message: _.get(err, 'message', 'Docusign Failed') }))
    });
}

export const getCheckoutId = (reqData) => {
    return ((dispatch, getState) => {
        dispatch({ type: ActionTypes.GET_CHECKOUTID_PENDING });
        AuthServices.getCheckoutId(reqData)
            .then(response => {
                dispatch({ type: ActionTypes.GET_CHECKOUTID_SUCCESS, payload: response});
            })
            .catch(err => dispatch({ type: ActionTypes.GET_CHECKOUTID_FAILURE, message: _.get(err, 'message', 'Docusign Failed') }))
    });
}

export const paymentReporting = (subscriber_id, type) => {
    return ((dispatch, getState) => {
        dispatch({ type: ActionTypes.POST_PAYMENT_REPORTING_PENDING });
        if (type === 'success') {
            AuthServices.paymentSuccess(subscriber_id)
                .then(response => {
                    dispatch({ type: ActionTypes.POST_PAYMENT_REPORTING_SUCCESS, message: _.get(response, 'message') });
                })
                .catch(err => dispatch({ type: ActionTypes.POST_PAYMENT_REPORTING_FAILURE, message: _.get(err, 'message', 'Payment Reporting Failed') }))
        } else {
            AuthServices.paymentFailure(subscriber_id)
                .then(response => {
                    dispatch({ type: ActionTypes.POST_PAYMENT_REPORTING_SUCCESS, message: _.get(response, 'message') });
                })
                .catch(err => dispatch({ type: ActionTypes.POST_PAYMENT_REPORTING_FAILURE, message: _.get(err, 'message', 'Payment Reporting Failed') }))
        }

    });
}

export const signOut = () => {
    return ((dispatch, state) => {
        localStorage.removeItem('userData');
        dispatch({ type: ActionTypes.SIGNOUT_SUCCESS });
    });
}