import * as AuthActions from './AuthActions';
import * as DashboardActions from './DashboardActions';

export const ActionCreators = Object.assign({},
    AuthActions, DashboardActions
);