import * as DashboardServices from '../Services/DashboardServices';
import * as ActionTypes from '../Actions/ActionTypes';

export const getEnergyScannerData = (month) => {
    return ((dispatch, getState) => {
        dispatch({ type: ActionTypes.GET_ENERGYSCANNERDATA_PENDING });
        DashboardServices.getEnergyScannerData(month)
            .then(response => {
                dispatch({ type: ActionTypes.GET_ENERGYSCANNERDATA_SUCCESS, payload: response.body });
            })
            .catch(err => dispatch({ type: ActionTypes.GET_ENERGYSCANNERDATA_FAILURE, message: 'Incorrect Credentials' }))
    });
}